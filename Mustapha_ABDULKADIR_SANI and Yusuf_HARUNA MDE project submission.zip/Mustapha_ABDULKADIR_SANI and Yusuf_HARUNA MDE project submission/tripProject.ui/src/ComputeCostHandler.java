/*import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;

import tripProject.LocalService;
import tripProject.Service;
import tripProject.Trip;
import tripProject.TripProjectFactory;
import tripProject.impl.*;
import tripProject.util.*;
import tripProject.TripProjectPackage;


public class ComputeCostHandler implements IHandler {

	@Override
	public void addHandlerListener(IHandlerListener handlerListener) {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		// TODO Auto-generated method stub
		TripImpl tr = new TripImpl();
		//tr.getService().size();
		System.out.print("Hello"+tr.getService().size());
		return null;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isHandled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void removeHandlerListener(IHandlerListener handlerListener) {
		// TODO Auto-generated method stub

	}

}
*/

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.IHandlerListener;

import tripProject.Service;
import tripProject.LocalService;
import tripProject.TransportService; 
import tripProject.Trip;
import tripProject.TripProjectFactory;
import tripProject.impl.*;
import tripProject.util.*;
import tripProject.TripProjectPackage;

public class ComputeCostHandler implements IHandler {
public void addHandlerListener(IHandlerListener handlerListener) {}
public void dispose() {}
public Object execute(ExecutionEvent event) throws ExecutionException {
// TODO Auto-generated method stub
	TripImpl trip = new TripImpl();
	for(int i = 0; i<trip.getService().size(); i++)
	
	System.out.println("here we want to print the computed cost, but we are facing some errors");
	return null;
}
public boolean isEnabled() { return true; }
public boolean isHandled() { return true; }
public void removeHandlerListener(IHandlerListener handlerListener) {}
}