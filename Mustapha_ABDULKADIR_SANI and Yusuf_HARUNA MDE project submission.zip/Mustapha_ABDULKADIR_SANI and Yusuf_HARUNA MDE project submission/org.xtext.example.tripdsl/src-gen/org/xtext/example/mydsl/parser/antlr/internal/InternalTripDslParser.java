package org.xtext.example.mydsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.mydsl.services.TripDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalTripDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_INT", "RULE_ID", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Trip'", "'{'", "'source'", "'London'", "'Paris'", "'Nice'", "'Humburg'", "'Berlin'", "'Texas'", "'Rome'", "'Moscow'", "'Abuja'", "'destination'", "'service'", "','", "'}'", "'TransportService'", "'AirFrance'", "'British-Air-ways'", "'FlixBus'", "'Taxi'", "'SNCF'", "'Car-rental'", "'Velo-Bike'", "'cost'", "'type'", "'Bus'", "'Train'", "'Plane'", "'Bike'", "'source-city'", "'destination-city'", "'LocalService'", "'Api'", "'B&B-Hotel'", "'Novotel'", "'Generator'", "'Le-Grand-Cafe'", "'location'", "'Restaurant'", "'Hotel'", "'-'", "'.'", "'E'", "'e'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_ID=5;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=4;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalTripDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalTripDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalTripDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalTripDsl.g"; }



     	private TripDslGrammarAccess grammarAccess;

        public InternalTripDslParser(TokenStream input, TripDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Trip";
       	}

       	@Override
       	protected TripDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleTrip"
    // InternalTripDsl.g:64:1: entryRuleTrip returns [EObject current=null] : iv_ruleTrip= ruleTrip EOF ;
    public final EObject entryRuleTrip() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTrip = null;


        try {
            // InternalTripDsl.g:64:45: (iv_ruleTrip= ruleTrip EOF )
            // InternalTripDsl.g:65:2: iv_ruleTrip= ruleTrip EOF
            {
             newCompositeNode(grammarAccess.getTripRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTrip=ruleTrip();

            state._fsp--;

             current =iv_ruleTrip; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTrip"


    // $ANTLR start "ruleTrip"
    // InternalTripDsl.g:71:1: ruleTrip returns [EObject current=null] : ( () otherlv_1= 'Trip' otherlv_2= '{' (otherlv_3= 'source' ( ( (lv_source_4_1= 'London' | lv_source_4_2= 'Paris' | lv_source_4_3= 'Nice' | lv_source_4_4= 'Humburg' | lv_source_4_5= 'Berlin' | lv_source_4_6= 'Texas' | lv_source_4_7= 'Rome' | lv_source_4_8= 'Moscow' | lv_source_4_9= 'Abuja' ) ) ) )? (otherlv_5= 'destination' ( ( (lv_destination_6_1= 'London' | lv_destination_6_2= 'Paris' | lv_destination_6_3= 'Nice' | lv_destination_6_4= 'Humburg' | lv_destination_6_5= 'Berlin' | lv_destination_6_6= 'Texas' | lv_destination_6_7= 'Rome' | lv_destination_6_8= 'Moscow' | lv_destination_6_9= 'Abuja' ) ) ) )? (otherlv_7= 'service' otherlv_8= '{' ( (lv_service_9_0= ruleService ) ) (otherlv_10= ',' ( (lv_service_11_0= ruleService ) ) )* otherlv_12= '}' )? otherlv_13= '}' ) ;
    public final EObject ruleTrip() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token lv_source_4_1=null;
        Token lv_source_4_2=null;
        Token lv_source_4_3=null;
        Token lv_source_4_4=null;
        Token lv_source_4_5=null;
        Token lv_source_4_6=null;
        Token lv_source_4_7=null;
        Token lv_source_4_8=null;
        Token lv_source_4_9=null;
        Token otherlv_5=null;
        Token lv_destination_6_1=null;
        Token lv_destination_6_2=null;
        Token lv_destination_6_3=null;
        Token lv_destination_6_4=null;
        Token lv_destination_6_5=null;
        Token lv_destination_6_6=null;
        Token lv_destination_6_7=null;
        Token lv_destination_6_8=null;
        Token lv_destination_6_9=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_13=null;
        EObject lv_service_9_0 = null;

        EObject lv_service_11_0 = null;



        	enterRule();

        try {
            // InternalTripDsl.g:77:2: ( ( () otherlv_1= 'Trip' otherlv_2= '{' (otherlv_3= 'source' ( ( (lv_source_4_1= 'London' | lv_source_4_2= 'Paris' | lv_source_4_3= 'Nice' | lv_source_4_4= 'Humburg' | lv_source_4_5= 'Berlin' | lv_source_4_6= 'Texas' | lv_source_4_7= 'Rome' | lv_source_4_8= 'Moscow' | lv_source_4_9= 'Abuja' ) ) ) )? (otherlv_5= 'destination' ( ( (lv_destination_6_1= 'London' | lv_destination_6_2= 'Paris' | lv_destination_6_3= 'Nice' | lv_destination_6_4= 'Humburg' | lv_destination_6_5= 'Berlin' | lv_destination_6_6= 'Texas' | lv_destination_6_7= 'Rome' | lv_destination_6_8= 'Moscow' | lv_destination_6_9= 'Abuja' ) ) ) )? (otherlv_7= 'service' otherlv_8= '{' ( (lv_service_9_0= ruleService ) ) (otherlv_10= ',' ( (lv_service_11_0= ruleService ) ) )* otherlv_12= '}' )? otherlv_13= '}' ) )
            // InternalTripDsl.g:78:2: ( () otherlv_1= 'Trip' otherlv_2= '{' (otherlv_3= 'source' ( ( (lv_source_4_1= 'London' | lv_source_4_2= 'Paris' | lv_source_4_3= 'Nice' | lv_source_4_4= 'Humburg' | lv_source_4_5= 'Berlin' | lv_source_4_6= 'Texas' | lv_source_4_7= 'Rome' | lv_source_4_8= 'Moscow' | lv_source_4_9= 'Abuja' ) ) ) )? (otherlv_5= 'destination' ( ( (lv_destination_6_1= 'London' | lv_destination_6_2= 'Paris' | lv_destination_6_3= 'Nice' | lv_destination_6_4= 'Humburg' | lv_destination_6_5= 'Berlin' | lv_destination_6_6= 'Texas' | lv_destination_6_7= 'Rome' | lv_destination_6_8= 'Moscow' | lv_destination_6_9= 'Abuja' ) ) ) )? (otherlv_7= 'service' otherlv_8= '{' ( (lv_service_9_0= ruleService ) ) (otherlv_10= ',' ( (lv_service_11_0= ruleService ) ) )* otherlv_12= '}' )? otherlv_13= '}' )
            {
            // InternalTripDsl.g:78:2: ( () otherlv_1= 'Trip' otherlv_2= '{' (otherlv_3= 'source' ( ( (lv_source_4_1= 'London' | lv_source_4_2= 'Paris' | lv_source_4_3= 'Nice' | lv_source_4_4= 'Humburg' | lv_source_4_5= 'Berlin' | lv_source_4_6= 'Texas' | lv_source_4_7= 'Rome' | lv_source_4_8= 'Moscow' | lv_source_4_9= 'Abuja' ) ) ) )? (otherlv_5= 'destination' ( ( (lv_destination_6_1= 'London' | lv_destination_6_2= 'Paris' | lv_destination_6_3= 'Nice' | lv_destination_6_4= 'Humburg' | lv_destination_6_5= 'Berlin' | lv_destination_6_6= 'Texas' | lv_destination_6_7= 'Rome' | lv_destination_6_8= 'Moscow' | lv_destination_6_9= 'Abuja' ) ) ) )? (otherlv_7= 'service' otherlv_8= '{' ( (lv_service_9_0= ruleService ) ) (otherlv_10= ',' ( (lv_service_11_0= ruleService ) ) )* otherlv_12= '}' )? otherlv_13= '}' )
            // InternalTripDsl.g:79:3: () otherlv_1= 'Trip' otherlv_2= '{' (otherlv_3= 'source' ( ( (lv_source_4_1= 'London' | lv_source_4_2= 'Paris' | lv_source_4_3= 'Nice' | lv_source_4_4= 'Humburg' | lv_source_4_5= 'Berlin' | lv_source_4_6= 'Texas' | lv_source_4_7= 'Rome' | lv_source_4_8= 'Moscow' | lv_source_4_9= 'Abuja' ) ) ) )? (otherlv_5= 'destination' ( ( (lv_destination_6_1= 'London' | lv_destination_6_2= 'Paris' | lv_destination_6_3= 'Nice' | lv_destination_6_4= 'Humburg' | lv_destination_6_5= 'Berlin' | lv_destination_6_6= 'Texas' | lv_destination_6_7= 'Rome' | lv_destination_6_8= 'Moscow' | lv_destination_6_9= 'Abuja' ) ) ) )? (otherlv_7= 'service' otherlv_8= '{' ( (lv_service_9_0= ruleService ) ) (otherlv_10= ',' ( (lv_service_11_0= ruleService ) ) )* otherlv_12= '}' )? otherlv_13= '}'
            {
            // InternalTripDsl.g:79:3: ()
            // InternalTripDsl.g:80:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getTripAccess().getTripAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getTripAccess().getTripKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_2, grammarAccess.getTripAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalTripDsl.g:94:3: (otherlv_3= 'source' ( ( (lv_source_4_1= 'London' | lv_source_4_2= 'Paris' | lv_source_4_3= 'Nice' | lv_source_4_4= 'Humburg' | lv_source_4_5= 'Berlin' | lv_source_4_6= 'Texas' | lv_source_4_7= 'Rome' | lv_source_4_8= 'Moscow' | lv_source_4_9= 'Abuja' ) ) ) )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==13) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalTripDsl.g:95:4: otherlv_3= 'source' ( ( (lv_source_4_1= 'London' | lv_source_4_2= 'Paris' | lv_source_4_3= 'Nice' | lv_source_4_4= 'Humburg' | lv_source_4_5= 'Berlin' | lv_source_4_6= 'Texas' | lv_source_4_7= 'Rome' | lv_source_4_8= 'Moscow' | lv_source_4_9= 'Abuja' ) ) )
                    {
                    otherlv_3=(Token)match(input,13,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getTripAccess().getSourceKeyword_3_0());
                    			
                    // InternalTripDsl.g:99:4: ( ( (lv_source_4_1= 'London' | lv_source_4_2= 'Paris' | lv_source_4_3= 'Nice' | lv_source_4_4= 'Humburg' | lv_source_4_5= 'Berlin' | lv_source_4_6= 'Texas' | lv_source_4_7= 'Rome' | lv_source_4_8= 'Moscow' | lv_source_4_9= 'Abuja' ) ) )
                    // InternalTripDsl.g:100:5: ( (lv_source_4_1= 'London' | lv_source_4_2= 'Paris' | lv_source_4_3= 'Nice' | lv_source_4_4= 'Humburg' | lv_source_4_5= 'Berlin' | lv_source_4_6= 'Texas' | lv_source_4_7= 'Rome' | lv_source_4_8= 'Moscow' | lv_source_4_9= 'Abuja' ) )
                    {
                    // InternalTripDsl.g:100:5: ( (lv_source_4_1= 'London' | lv_source_4_2= 'Paris' | lv_source_4_3= 'Nice' | lv_source_4_4= 'Humburg' | lv_source_4_5= 'Berlin' | lv_source_4_6= 'Texas' | lv_source_4_7= 'Rome' | lv_source_4_8= 'Moscow' | lv_source_4_9= 'Abuja' ) )
                    // InternalTripDsl.g:101:6: (lv_source_4_1= 'London' | lv_source_4_2= 'Paris' | lv_source_4_3= 'Nice' | lv_source_4_4= 'Humburg' | lv_source_4_5= 'Berlin' | lv_source_4_6= 'Texas' | lv_source_4_7= 'Rome' | lv_source_4_8= 'Moscow' | lv_source_4_9= 'Abuja' )
                    {
                    // InternalTripDsl.g:101:6: (lv_source_4_1= 'London' | lv_source_4_2= 'Paris' | lv_source_4_3= 'Nice' | lv_source_4_4= 'Humburg' | lv_source_4_5= 'Berlin' | lv_source_4_6= 'Texas' | lv_source_4_7= 'Rome' | lv_source_4_8= 'Moscow' | lv_source_4_9= 'Abuja' )
                    int alt1=9;
                    switch ( input.LA(1) ) {
                    case 14:
                        {
                        alt1=1;
                        }
                        break;
                    case 15:
                        {
                        alt1=2;
                        }
                        break;
                    case 16:
                        {
                        alt1=3;
                        }
                        break;
                    case 17:
                        {
                        alt1=4;
                        }
                        break;
                    case 18:
                        {
                        alt1=5;
                        }
                        break;
                    case 19:
                        {
                        alt1=6;
                        }
                        break;
                    case 20:
                        {
                        alt1=7;
                        }
                        break;
                    case 21:
                        {
                        alt1=8;
                        }
                        break;
                    case 22:
                        {
                        alt1=9;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 1, 0, input);

                        throw nvae;
                    }

                    switch (alt1) {
                        case 1 :
                            // InternalTripDsl.g:102:7: lv_source_4_1= 'London'
                            {
                            lv_source_4_1=(Token)match(input,14,FOLLOW_6); 

                            							newLeafNode(lv_source_4_1, grammarAccess.getTripAccess().getSourceLondonKeyword_3_1_0_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "source", lv_source_4_1, null);
                            						

                            }
                            break;
                        case 2 :
                            // InternalTripDsl.g:113:7: lv_source_4_2= 'Paris'
                            {
                            lv_source_4_2=(Token)match(input,15,FOLLOW_6); 

                            							newLeafNode(lv_source_4_2, grammarAccess.getTripAccess().getSourceParisKeyword_3_1_0_1());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "source", lv_source_4_2, null);
                            						

                            }
                            break;
                        case 3 :
                            // InternalTripDsl.g:124:7: lv_source_4_3= 'Nice'
                            {
                            lv_source_4_3=(Token)match(input,16,FOLLOW_6); 

                            							newLeafNode(lv_source_4_3, grammarAccess.getTripAccess().getSourceNiceKeyword_3_1_0_2());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "source", lv_source_4_3, null);
                            						

                            }
                            break;
                        case 4 :
                            // InternalTripDsl.g:135:7: lv_source_4_4= 'Humburg'
                            {
                            lv_source_4_4=(Token)match(input,17,FOLLOW_6); 

                            							newLeafNode(lv_source_4_4, grammarAccess.getTripAccess().getSourceHumburgKeyword_3_1_0_3());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "source", lv_source_4_4, null);
                            						

                            }
                            break;
                        case 5 :
                            // InternalTripDsl.g:146:7: lv_source_4_5= 'Berlin'
                            {
                            lv_source_4_5=(Token)match(input,18,FOLLOW_6); 

                            							newLeafNode(lv_source_4_5, grammarAccess.getTripAccess().getSourceBerlinKeyword_3_1_0_4());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "source", lv_source_4_5, null);
                            						

                            }
                            break;
                        case 6 :
                            // InternalTripDsl.g:157:7: lv_source_4_6= 'Texas'
                            {
                            lv_source_4_6=(Token)match(input,19,FOLLOW_6); 

                            							newLeafNode(lv_source_4_6, grammarAccess.getTripAccess().getSourceTexasKeyword_3_1_0_5());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "source", lv_source_4_6, null);
                            						

                            }
                            break;
                        case 7 :
                            // InternalTripDsl.g:168:7: lv_source_4_7= 'Rome'
                            {
                            lv_source_4_7=(Token)match(input,20,FOLLOW_6); 

                            							newLeafNode(lv_source_4_7, grammarAccess.getTripAccess().getSourceRomeKeyword_3_1_0_6());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "source", lv_source_4_7, null);
                            						

                            }
                            break;
                        case 8 :
                            // InternalTripDsl.g:179:7: lv_source_4_8= 'Moscow'
                            {
                            lv_source_4_8=(Token)match(input,21,FOLLOW_6); 

                            							newLeafNode(lv_source_4_8, grammarAccess.getTripAccess().getSourceMoscowKeyword_3_1_0_7());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "source", lv_source_4_8, null);
                            						

                            }
                            break;
                        case 9 :
                            // InternalTripDsl.g:190:7: lv_source_4_9= 'Abuja'
                            {
                            lv_source_4_9=(Token)match(input,22,FOLLOW_6); 

                            							newLeafNode(lv_source_4_9, grammarAccess.getTripAccess().getSourceAbujaKeyword_3_1_0_8());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "source", lv_source_4_9, null);
                            						

                            }
                            break;

                    }


                    }


                    }


                    }
                    break;

            }

            // InternalTripDsl.g:204:3: (otherlv_5= 'destination' ( ( (lv_destination_6_1= 'London' | lv_destination_6_2= 'Paris' | lv_destination_6_3= 'Nice' | lv_destination_6_4= 'Humburg' | lv_destination_6_5= 'Berlin' | lv_destination_6_6= 'Texas' | lv_destination_6_7= 'Rome' | lv_destination_6_8= 'Moscow' | lv_destination_6_9= 'Abuja' ) ) ) )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==23) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalTripDsl.g:205:4: otherlv_5= 'destination' ( ( (lv_destination_6_1= 'London' | lv_destination_6_2= 'Paris' | lv_destination_6_3= 'Nice' | lv_destination_6_4= 'Humburg' | lv_destination_6_5= 'Berlin' | lv_destination_6_6= 'Texas' | lv_destination_6_7= 'Rome' | lv_destination_6_8= 'Moscow' | lv_destination_6_9= 'Abuja' ) ) )
                    {
                    otherlv_5=(Token)match(input,23,FOLLOW_5); 

                    				newLeafNode(otherlv_5, grammarAccess.getTripAccess().getDestinationKeyword_4_0());
                    			
                    // InternalTripDsl.g:209:4: ( ( (lv_destination_6_1= 'London' | lv_destination_6_2= 'Paris' | lv_destination_6_3= 'Nice' | lv_destination_6_4= 'Humburg' | lv_destination_6_5= 'Berlin' | lv_destination_6_6= 'Texas' | lv_destination_6_7= 'Rome' | lv_destination_6_8= 'Moscow' | lv_destination_6_9= 'Abuja' ) ) )
                    // InternalTripDsl.g:210:5: ( (lv_destination_6_1= 'London' | lv_destination_6_2= 'Paris' | lv_destination_6_3= 'Nice' | lv_destination_6_4= 'Humburg' | lv_destination_6_5= 'Berlin' | lv_destination_6_6= 'Texas' | lv_destination_6_7= 'Rome' | lv_destination_6_8= 'Moscow' | lv_destination_6_9= 'Abuja' ) )
                    {
                    // InternalTripDsl.g:210:5: ( (lv_destination_6_1= 'London' | lv_destination_6_2= 'Paris' | lv_destination_6_3= 'Nice' | lv_destination_6_4= 'Humburg' | lv_destination_6_5= 'Berlin' | lv_destination_6_6= 'Texas' | lv_destination_6_7= 'Rome' | lv_destination_6_8= 'Moscow' | lv_destination_6_9= 'Abuja' ) )
                    // InternalTripDsl.g:211:6: (lv_destination_6_1= 'London' | lv_destination_6_2= 'Paris' | lv_destination_6_3= 'Nice' | lv_destination_6_4= 'Humburg' | lv_destination_6_5= 'Berlin' | lv_destination_6_6= 'Texas' | lv_destination_6_7= 'Rome' | lv_destination_6_8= 'Moscow' | lv_destination_6_9= 'Abuja' )
                    {
                    // InternalTripDsl.g:211:6: (lv_destination_6_1= 'London' | lv_destination_6_2= 'Paris' | lv_destination_6_3= 'Nice' | lv_destination_6_4= 'Humburg' | lv_destination_6_5= 'Berlin' | lv_destination_6_6= 'Texas' | lv_destination_6_7= 'Rome' | lv_destination_6_8= 'Moscow' | lv_destination_6_9= 'Abuja' )
                    int alt3=9;
                    switch ( input.LA(1) ) {
                    case 14:
                        {
                        alt3=1;
                        }
                        break;
                    case 15:
                        {
                        alt3=2;
                        }
                        break;
                    case 16:
                        {
                        alt3=3;
                        }
                        break;
                    case 17:
                        {
                        alt3=4;
                        }
                        break;
                    case 18:
                        {
                        alt3=5;
                        }
                        break;
                    case 19:
                        {
                        alt3=6;
                        }
                        break;
                    case 20:
                        {
                        alt3=7;
                        }
                        break;
                    case 21:
                        {
                        alt3=8;
                        }
                        break;
                    case 22:
                        {
                        alt3=9;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 3, 0, input);

                        throw nvae;
                    }

                    switch (alt3) {
                        case 1 :
                            // InternalTripDsl.g:212:7: lv_destination_6_1= 'London'
                            {
                            lv_destination_6_1=(Token)match(input,14,FOLLOW_7); 

                            							newLeafNode(lv_destination_6_1, grammarAccess.getTripAccess().getDestinationLondonKeyword_4_1_0_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "destination", lv_destination_6_1, null);
                            						

                            }
                            break;
                        case 2 :
                            // InternalTripDsl.g:223:7: lv_destination_6_2= 'Paris'
                            {
                            lv_destination_6_2=(Token)match(input,15,FOLLOW_7); 

                            							newLeafNode(lv_destination_6_2, grammarAccess.getTripAccess().getDestinationParisKeyword_4_1_0_1());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "destination", lv_destination_6_2, null);
                            						

                            }
                            break;
                        case 3 :
                            // InternalTripDsl.g:234:7: lv_destination_6_3= 'Nice'
                            {
                            lv_destination_6_3=(Token)match(input,16,FOLLOW_7); 

                            							newLeafNode(lv_destination_6_3, grammarAccess.getTripAccess().getDestinationNiceKeyword_4_1_0_2());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "destination", lv_destination_6_3, null);
                            						

                            }
                            break;
                        case 4 :
                            // InternalTripDsl.g:245:7: lv_destination_6_4= 'Humburg'
                            {
                            lv_destination_6_4=(Token)match(input,17,FOLLOW_7); 

                            							newLeafNode(lv_destination_6_4, grammarAccess.getTripAccess().getDestinationHumburgKeyword_4_1_0_3());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "destination", lv_destination_6_4, null);
                            						

                            }
                            break;
                        case 5 :
                            // InternalTripDsl.g:256:7: lv_destination_6_5= 'Berlin'
                            {
                            lv_destination_6_5=(Token)match(input,18,FOLLOW_7); 

                            							newLeafNode(lv_destination_6_5, grammarAccess.getTripAccess().getDestinationBerlinKeyword_4_1_0_4());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "destination", lv_destination_6_5, null);
                            						

                            }
                            break;
                        case 6 :
                            // InternalTripDsl.g:267:7: lv_destination_6_6= 'Texas'
                            {
                            lv_destination_6_6=(Token)match(input,19,FOLLOW_7); 

                            							newLeafNode(lv_destination_6_6, grammarAccess.getTripAccess().getDestinationTexasKeyword_4_1_0_5());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "destination", lv_destination_6_6, null);
                            						

                            }
                            break;
                        case 7 :
                            // InternalTripDsl.g:278:7: lv_destination_6_7= 'Rome'
                            {
                            lv_destination_6_7=(Token)match(input,20,FOLLOW_7); 

                            							newLeafNode(lv_destination_6_7, grammarAccess.getTripAccess().getDestinationRomeKeyword_4_1_0_6());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "destination", lv_destination_6_7, null);
                            						

                            }
                            break;
                        case 8 :
                            // InternalTripDsl.g:289:7: lv_destination_6_8= 'Moscow'
                            {
                            lv_destination_6_8=(Token)match(input,21,FOLLOW_7); 

                            							newLeafNode(lv_destination_6_8, grammarAccess.getTripAccess().getDestinationMoscowKeyword_4_1_0_7());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "destination", lv_destination_6_8, null);
                            						

                            }
                            break;
                        case 9 :
                            // InternalTripDsl.g:300:7: lv_destination_6_9= 'Abuja'
                            {
                            lv_destination_6_9=(Token)match(input,22,FOLLOW_7); 

                            							newLeafNode(lv_destination_6_9, grammarAccess.getTripAccess().getDestinationAbujaKeyword_4_1_0_8());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTripRule());
                            							}
                            							setWithLastConsumed(current, "destination", lv_destination_6_9, null);
                            						

                            }
                            break;

                    }


                    }


                    }


                    }
                    break;

            }

            // InternalTripDsl.g:314:3: (otherlv_7= 'service' otherlv_8= '{' ( (lv_service_9_0= ruleService ) ) (otherlv_10= ',' ( (lv_service_11_0= ruleService ) ) )* otherlv_12= '}' )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==24) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalTripDsl.g:315:4: otherlv_7= 'service' otherlv_8= '{' ( (lv_service_9_0= ruleService ) ) (otherlv_10= ',' ( (lv_service_11_0= ruleService ) ) )* otherlv_12= '}'
                    {
                    otherlv_7=(Token)match(input,24,FOLLOW_3); 

                    				newLeafNode(otherlv_7, grammarAccess.getTripAccess().getServiceKeyword_5_0());
                    			
                    otherlv_8=(Token)match(input,12,FOLLOW_8); 

                    				newLeafNode(otherlv_8, grammarAccess.getTripAccess().getLeftCurlyBracketKeyword_5_1());
                    			
                    // InternalTripDsl.g:323:4: ( (lv_service_9_0= ruleService ) )
                    // InternalTripDsl.g:324:5: (lv_service_9_0= ruleService )
                    {
                    // InternalTripDsl.g:324:5: (lv_service_9_0= ruleService )
                    // InternalTripDsl.g:325:6: lv_service_9_0= ruleService
                    {

                    						newCompositeNode(grammarAccess.getTripAccess().getServiceServiceParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_9);
                    lv_service_9_0=ruleService();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getTripRule());
                    						}
                    						add(
                    							current,
                    							"service",
                    							lv_service_9_0,
                    							"org.xtext.example.mydsl.TripDsl.Service");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalTripDsl.g:342:4: (otherlv_10= ',' ( (lv_service_11_0= ruleService ) ) )*
                    loop5:
                    do {
                        int alt5=2;
                        int LA5_0 = input.LA(1);

                        if ( (LA5_0==25) ) {
                            alt5=1;
                        }


                        switch (alt5) {
                    	case 1 :
                    	    // InternalTripDsl.g:343:5: otherlv_10= ',' ( (lv_service_11_0= ruleService ) )
                    	    {
                    	    otherlv_10=(Token)match(input,25,FOLLOW_8); 

                    	    					newLeafNode(otherlv_10, grammarAccess.getTripAccess().getCommaKeyword_5_3_0());
                    	    				
                    	    // InternalTripDsl.g:347:5: ( (lv_service_11_0= ruleService ) )
                    	    // InternalTripDsl.g:348:6: (lv_service_11_0= ruleService )
                    	    {
                    	    // InternalTripDsl.g:348:6: (lv_service_11_0= ruleService )
                    	    // InternalTripDsl.g:349:7: lv_service_11_0= ruleService
                    	    {

                    	    							newCompositeNode(grammarAccess.getTripAccess().getServiceServiceParserRuleCall_5_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_9);
                    	    lv_service_11_0=ruleService();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getTripRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"service",
                    	    								lv_service_11_0,
                    	    								"org.xtext.example.mydsl.TripDsl.Service");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop5;
                        }
                    } while (true);

                    otherlv_12=(Token)match(input,26,FOLLOW_10); 

                    				newLeafNode(otherlv_12, grammarAccess.getTripAccess().getRightCurlyBracketKeyword_5_4());
                    			

                    }
                    break;

            }

            otherlv_13=(Token)match(input,26,FOLLOW_2); 

            			newLeafNode(otherlv_13, grammarAccess.getTripAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTrip"


    // $ANTLR start "entryRuleService"
    // InternalTripDsl.g:380:1: entryRuleService returns [EObject current=null] : iv_ruleService= ruleService EOF ;
    public final EObject entryRuleService() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleService = null;


        try {
            // InternalTripDsl.g:380:48: (iv_ruleService= ruleService EOF )
            // InternalTripDsl.g:381:2: iv_ruleService= ruleService EOF
            {
             newCompositeNode(grammarAccess.getServiceRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleService=ruleService();

            state._fsp--;

             current =iv_ruleService; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleService"


    // $ANTLR start "ruleService"
    // InternalTripDsl.g:387:1: ruleService returns [EObject current=null] : (this_TransportService_0= ruleTransportService | this_LocalService_1= ruleLocalService ) ;
    public final EObject ruleService() throws RecognitionException {
        EObject current = null;

        EObject this_TransportService_0 = null;

        EObject this_LocalService_1 = null;



        	enterRule();

        try {
            // InternalTripDsl.g:393:2: ( (this_TransportService_0= ruleTransportService | this_LocalService_1= ruleLocalService ) )
            // InternalTripDsl.g:394:2: (this_TransportService_0= ruleTransportService | this_LocalService_1= ruleLocalService )
            {
            // InternalTripDsl.g:394:2: (this_TransportService_0= ruleTransportService | this_LocalService_1= ruleLocalService )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==27) ) {
                alt7=1;
            }
            else if ( (LA7_0==43) ) {
                alt7=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalTripDsl.g:395:3: this_TransportService_0= ruleTransportService
                    {

                    			newCompositeNode(grammarAccess.getServiceAccess().getTransportServiceParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_TransportService_0=ruleTransportService();

                    state._fsp--;


                    			current = this_TransportService_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalTripDsl.g:404:3: this_LocalService_1= ruleLocalService
                    {

                    			newCompositeNode(grammarAccess.getServiceAccess().getLocalServiceParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_LocalService_1=ruleLocalService();

                    state._fsp--;


                    			current = this_LocalService_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleService"


    // $ANTLR start "entryRuleTransportService"
    // InternalTripDsl.g:416:1: entryRuleTransportService returns [EObject current=null] : iv_ruleTransportService= ruleTransportService EOF ;
    public final EObject entryRuleTransportService() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTransportService = null;


        try {
            // InternalTripDsl.g:416:57: (iv_ruleTransportService= ruleTransportService EOF )
            // InternalTripDsl.g:417:2: iv_ruleTransportService= ruleTransportService EOF
            {
             newCompositeNode(grammarAccess.getTransportServiceRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTransportService=ruleTransportService();

            state._fsp--;

             current =iv_ruleTransportService; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTransportService"


    // $ANTLR start "ruleTransportService"
    // InternalTripDsl.g:423:1: ruleTransportService returns [EObject current=null] : ( () otherlv_1= 'TransportService' ( ( (lv_name_2_1= 'AirFrance' | lv_name_2_2= 'British-Air-ways' | lv_name_2_3= 'FlixBus' | lv_name_2_4= 'Taxi' | lv_name_2_5= 'SNCF' | lv_name_2_6= 'Car-rental' | lv_name_2_7= 'Velo-Bike' ) ) ) otherlv_3= '{' (otherlv_4= 'cost' ( (lv_cost_5_0= ruleEDouble ) ) )? (otherlv_6= 'type' ( ( (lv_type_7_1= 'Bus' | lv_type_7_2= 'Train' | lv_type_7_3= 'Plane' | lv_type_7_4= 'Car-rental' | lv_type_7_5= 'Bike' | lv_type_7_6= 'Taxi' ) ) ) )? (otherlv_8= 'source-city' ( ( (lv_srce_9_1= 'London' | lv_srce_9_2= 'Paris' | lv_srce_9_3= 'Nice' | lv_srce_9_4= 'Humburg' | lv_srce_9_5= 'Berlin' | lv_srce_9_6= 'Texas' | lv_srce_9_7= 'Rome' | lv_srce_9_8= 'Moscow' | lv_srce_9_9= 'Abuja' ) ) ) )? (otherlv_10= 'destination-city' ( ( (lv_dest_11_1= 'London' | lv_dest_11_2= 'Paris' | lv_dest_11_3= 'Nice' | lv_dest_11_4= 'Humburg' | lv_dest_11_5= 'Berlin' | lv_dest_11_6= 'Texas' | lv_dest_11_7= 'Rome' | lv_dest_11_8= 'Moscow' | lv_dest_11_9= 'Abuja' ) ) ) )? otherlv_12= '}' ) ;
    public final EObject ruleTransportService() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token lv_name_2_1=null;
        Token lv_name_2_2=null;
        Token lv_name_2_3=null;
        Token lv_name_2_4=null;
        Token lv_name_2_5=null;
        Token lv_name_2_6=null;
        Token lv_name_2_7=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token lv_type_7_1=null;
        Token lv_type_7_2=null;
        Token lv_type_7_3=null;
        Token lv_type_7_4=null;
        Token lv_type_7_5=null;
        Token lv_type_7_6=null;
        Token otherlv_8=null;
        Token lv_srce_9_1=null;
        Token lv_srce_9_2=null;
        Token lv_srce_9_3=null;
        Token lv_srce_9_4=null;
        Token lv_srce_9_5=null;
        Token lv_srce_9_6=null;
        Token lv_srce_9_7=null;
        Token lv_srce_9_8=null;
        Token lv_srce_9_9=null;
        Token otherlv_10=null;
        Token lv_dest_11_1=null;
        Token lv_dest_11_2=null;
        Token lv_dest_11_3=null;
        Token lv_dest_11_4=null;
        Token lv_dest_11_5=null;
        Token lv_dest_11_6=null;
        Token lv_dest_11_7=null;
        Token lv_dest_11_8=null;
        Token lv_dest_11_9=null;
        Token otherlv_12=null;
        AntlrDatatypeRuleToken lv_cost_5_0 = null;



        	enterRule();

        try {
            // InternalTripDsl.g:429:2: ( ( () otherlv_1= 'TransportService' ( ( (lv_name_2_1= 'AirFrance' | lv_name_2_2= 'British-Air-ways' | lv_name_2_3= 'FlixBus' | lv_name_2_4= 'Taxi' | lv_name_2_5= 'SNCF' | lv_name_2_6= 'Car-rental' | lv_name_2_7= 'Velo-Bike' ) ) ) otherlv_3= '{' (otherlv_4= 'cost' ( (lv_cost_5_0= ruleEDouble ) ) )? (otherlv_6= 'type' ( ( (lv_type_7_1= 'Bus' | lv_type_7_2= 'Train' | lv_type_7_3= 'Plane' | lv_type_7_4= 'Car-rental' | lv_type_7_5= 'Bike' | lv_type_7_6= 'Taxi' ) ) ) )? (otherlv_8= 'source-city' ( ( (lv_srce_9_1= 'London' | lv_srce_9_2= 'Paris' | lv_srce_9_3= 'Nice' | lv_srce_9_4= 'Humburg' | lv_srce_9_5= 'Berlin' | lv_srce_9_6= 'Texas' | lv_srce_9_7= 'Rome' | lv_srce_9_8= 'Moscow' | lv_srce_9_9= 'Abuja' ) ) ) )? (otherlv_10= 'destination-city' ( ( (lv_dest_11_1= 'London' | lv_dest_11_2= 'Paris' | lv_dest_11_3= 'Nice' | lv_dest_11_4= 'Humburg' | lv_dest_11_5= 'Berlin' | lv_dest_11_6= 'Texas' | lv_dest_11_7= 'Rome' | lv_dest_11_8= 'Moscow' | lv_dest_11_9= 'Abuja' ) ) ) )? otherlv_12= '}' ) )
            // InternalTripDsl.g:430:2: ( () otherlv_1= 'TransportService' ( ( (lv_name_2_1= 'AirFrance' | lv_name_2_2= 'British-Air-ways' | lv_name_2_3= 'FlixBus' | lv_name_2_4= 'Taxi' | lv_name_2_5= 'SNCF' | lv_name_2_6= 'Car-rental' | lv_name_2_7= 'Velo-Bike' ) ) ) otherlv_3= '{' (otherlv_4= 'cost' ( (lv_cost_5_0= ruleEDouble ) ) )? (otherlv_6= 'type' ( ( (lv_type_7_1= 'Bus' | lv_type_7_2= 'Train' | lv_type_7_3= 'Plane' | lv_type_7_4= 'Car-rental' | lv_type_7_5= 'Bike' | lv_type_7_6= 'Taxi' ) ) ) )? (otherlv_8= 'source-city' ( ( (lv_srce_9_1= 'London' | lv_srce_9_2= 'Paris' | lv_srce_9_3= 'Nice' | lv_srce_9_4= 'Humburg' | lv_srce_9_5= 'Berlin' | lv_srce_9_6= 'Texas' | lv_srce_9_7= 'Rome' | lv_srce_9_8= 'Moscow' | lv_srce_9_9= 'Abuja' ) ) ) )? (otherlv_10= 'destination-city' ( ( (lv_dest_11_1= 'London' | lv_dest_11_2= 'Paris' | lv_dest_11_3= 'Nice' | lv_dest_11_4= 'Humburg' | lv_dest_11_5= 'Berlin' | lv_dest_11_6= 'Texas' | lv_dest_11_7= 'Rome' | lv_dest_11_8= 'Moscow' | lv_dest_11_9= 'Abuja' ) ) ) )? otherlv_12= '}' )
            {
            // InternalTripDsl.g:430:2: ( () otherlv_1= 'TransportService' ( ( (lv_name_2_1= 'AirFrance' | lv_name_2_2= 'British-Air-ways' | lv_name_2_3= 'FlixBus' | lv_name_2_4= 'Taxi' | lv_name_2_5= 'SNCF' | lv_name_2_6= 'Car-rental' | lv_name_2_7= 'Velo-Bike' ) ) ) otherlv_3= '{' (otherlv_4= 'cost' ( (lv_cost_5_0= ruleEDouble ) ) )? (otherlv_6= 'type' ( ( (lv_type_7_1= 'Bus' | lv_type_7_2= 'Train' | lv_type_7_3= 'Plane' | lv_type_7_4= 'Car-rental' | lv_type_7_5= 'Bike' | lv_type_7_6= 'Taxi' ) ) ) )? (otherlv_8= 'source-city' ( ( (lv_srce_9_1= 'London' | lv_srce_9_2= 'Paris' | lv_srce_9_3= 'Nice' | lv_srce_9_4= 'Humburg' | lv_srce_9_5= 'Berlin' | lv_srce_9_6= 'Texas' | lv_srce_9_7= 'Rome' | lv_srce_9_8= 'Moscow' | lv_srce_9_9= 'Abuja' ) ) ) )? (otherlv_10= 'destination-city' ( ( (lv_dest_11_1= 'London' | lv_dest_11_2= 'Paris' | lv_dest_11_3= 'Nice' | lv_dest_11_4= 'Humburg' | lv_dest_11_5= 'Berlin' | lv_dest_11_6= 'Texas' | lv_dest_11_7= 'Rome' | lv_dest_11_8= 'Moscow' | lv_dest_11_9= 'Abuja' ) ) ) )? otherlv_12= '}' )
            // InternalTripDsl.g:431:3: () otherlv_1= 'TransportService' ( ( (lv_name_2_1= 'AirFrance' | lv_name_2_2= 'British-Air-ways' | lv_name_2_3= 'FlixBus' | lv_name_2_4= 'Taxi' | lv_name_2_5= 'SNCF' | lv_name_2_6= 'Car-rental' | lv_name_2_7= 'Velo-Bike' ) ) ) otherlv_3= '{' (otherlv_4= 'cost' ( (lv_cost_5_0= ruleEDouble ) ) )? (otherlv_6= 'type' ( ( (lv_type_7_1= 'Bus' | lv_type_7_2= 'Train' | lv_type_7_3= 'Plane' | lv_type_7_4= 'Car-rental' | lv_type_7_5= 'Bike' | lv_type_7_6= 'Taxi' ) ) ) )? (otherlv_8= 'source-city' ( ( (lv_srce_9_1= 'London' | lv_srce_9_2= 'Paris' | lv_srce_9_3= 'Nice' | lv_srce_9_4= 'Humburg' | lv_srce_9_5= 'Berlin' | lv_srce_9_6= 'Texas' | lv_srce_9_7= 'Rome' | lv_srce_9_8= 'Moscow' | lv_srce_9_9= 'Abuja' ) ) ) )? (otherlv_10= 'destination-city' ( ( (lv_dest_11_1= 'London' | lv_dest_11_2= 'Paris' | lv_dest_11_3= 'Nice' | lv_dest_11_4= 'Humburg' | lv_dest_11_5= 'Berlin' | lv_dest_11_6= 'Texas' | lv_dest_11_7= 'Rome' | lv_dest_11_8= 'Moscow' | lv_dest_11_9= 'Abuja' ) ) ) )? otherlv_12= '}'
            {
            // InternalTripDsl.g:431:3: ()
            // InternalTripDsl.g:432:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getTransportServiceAccess().getTransportServiceAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,27,FOLLOW_11); 

            			newLeafNode(otherlv_1, grammarAccess.getTransportServiceAccess().getTransportServiceKeyword_1());
            		
            // InternalTripDsl.g:442:3: ( ( (lv_name_2_1= 'AirFrance' | lv_name_2_2= 'British-Air-ways' | lv_name_2_3= 'FlixBus' | lv_name_2_4= 'Taxi' | lv_name_2_5= 'SNCF' | lv_name_2_6= 'Car-rental' | lv_name_2_7= 'Velo-Bike' ) ) )
            // InternalTripDsl.g:443:4: ( (lv_name_2_1= 'AirFrance' | lv_name_2_2= 'British-Air-ways' | lv_name_2_3= 'FlixBus' | lv_name_2_4= 'Taxi' | lv_name_2_5= 'SNCF' | lv_name_2_6= 'Car-rental' | lv_name_2_7= 'Velo-Bike' ) )
            {
            // InternalTripDsl.g:443:4: ( (lv_name_2_1= 'AirFrance' | lv_name_2_2= 'British-Air-ways' | lv_name_2_3= 'FlixBus' | lv_name_2_4= 'Taxi' | lv_name_2_5= 'SNCF' | lv_name_2_6= 'Car-rental' | lv_name_2_7= 'Velo-Bike' ) )
            // InternalTripDsl.g:444:5: (lv_name_2_1= 'AirFrance' | lv_name_2_2= 'British-Air-ways' | lv_name_2_3= 'FlixBus' | lv_name_2_4= 'Taxi' | lv_name_2_5= 'SNCF' | lv_name_2_6= 'Car-rental' | lv_name_2_7= 'Velo-Bike' )
            {
            // InternalTripDsl.g:444:5: (lv_name_2_1= 'AirFrance' | lv_name_2_2= 'British-Air-ways' | lv_name_2_3= 'FlixBus' | lv_name_2_4= 'Taxi' | lv_name_2_5= 'SNCF' | lv_name_2_6= 'Car-rental' | lv_name_2_7= 'Velo-Bike' )
            int alt8=7;
            switch ( input.LA(1) ) {
            case 28:
                {
                alt8=1;
                }
                break;
            case 29:
                {
                alt8=2;
                }
                break;
            case 30:
                {
                alt8=3;
                }
                break;
            case 31:
                {
                alt8=4;
                }
                break;
            case 32:
                {
                alt8=5;
                }
                break;
            case 33:
                {
                alt8=6;
                }
                break;
            case 34:
                {
                alt8=7;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }

            switch (alt8) {
                case 1 :
                    // InternalTripDsl.g:445:6: lv_name_2_1= 'AirFrance'
                    {
                    lv_name_2_1=(Token)match(input,28,FOLLOW_3); 

                    						newLeafNode(lv_name_2_1, grammarAccess.getTransportServiceAccess().getNameAirFranceKeyword_2_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTransportServiceRule());
                    						}
                    						setWithLastConsumed(current, "name", lv_name_2_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalTripDsl.g:456:6: lv_name_2_2= 'British-Air-ways'
                    {
                    lv_name_2_2=(Token)match(input,29,FOLLOW_3); 

                    						newLeafNode(lv_name_2_2, grammarAccess.getTransportServiceAccess().getNameBritishAirWaysKeyword_2_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTransportServiceRule());
                    						}
                    						setWithLastConsumed(current, "name", lv_name_2_2, null);
                    					

                    }
                    break;
                case 3 :
                    // InternalTripDsl.g:467:6: lv_name_2_3= 'FlixBus'
                    {
                    lv_name_2_3=(Token)match(input,30,FOLLOW_3); 

                    						newLeafNode(lv_name_2_3, grammarAccess.getTransportServiceAccess().getNameFlixBusKeyword_2_0_2());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTransportServiceRule());
                    						}
                    						setWithLastConsumed(current, "name", lv_name_2_3, null);
                    					

                    }
                    break;
                case 4 :
                    // InternalTripDsl.g:478:6: lv_name_2_4= 'Taxi'
                    {
                    lv_name_2_4=(Token)match(input,31,FOLLOW_3); 

                    						newLeafNode(lv_name_2_4, grammarAccess.getTransportServiceAccess().getNameTaxiKeyword_2_0_3());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTransportServiceRule());
                    						}
                    						setWithLastConsumed(current, "name", lv_name_2_4, null);
                    					

                    }
                    break;
                case 5 :
                    // InternalTripDsl.g:489:6: lv_name_2_5= 'SNCF'
                    {
                    lv_name_2_5=(Token)match(input,32,FOLLOW_3); 

                    						newLeafNode(lv_name_2_5, grammarAccess.getTransportServiceAccess().getNameSNCFKeyword_2_0_4());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTransportServiceRule());
                    						}
                    						setWithLastConsumed(current, "name", lv_name_2_5, null);
                    					

                    }
                    break;
                case 6 :
                    // InternalTripDsl.g:500:6: lv_name_2_6= 'Car-rental'
                    {
                    lv_name_2_6=(Token)match(input,33,FOLLOW_3); 

                    						newLeafNode(lv_name_2_6, grammarAccess.getTransportServiceAccess().getNameCarRentalKeyword_2_0_5());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTransportServiceRule());
                    						}
                    						setWithLastConsumed(current, "name", lv_name_2_6, null);
                    					

                    }
                    break;
                case 7 :
                    // InternalTripDsl.g:511:6: lv_name_2_7= 'Velo-Bike'
                    {
                    lv_name_2_7=(Token)match(input,34,FOLLOW_3); 

                    						newLeafNode(lv_name_2_7, grammarAccess.getTransportServiceAccess().getNameVeloBikeKeyword_2_0_6());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTransportServiceRule());
                    						}
                    						setWithLastConsumed(current, "name", lv_name_2_7, null);
                    					

                    }
                    break;

            }


            }


            }

            otherlv_3=(Token)match(input,12,FOLLOW_12); 

            			newLeafNode(otherlv_3, grammarAccess.getTransportServiceAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalTripDsl.g:528:3: (otherlv_4= 'cost' ( (lv_cost_5_0= ruleEDouble ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==35) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalTripDsl.g:529:4: otherlv_4= 'cost' ( (lv_cost_5_0= ruleEDouble ) )
                    {
                    otherlv_4=(Token)match(input,35,FOLLOW_13); 

                    				newLeafNode(otherlv_4, grammarAccess.getTransportServiceAccess().getCostKeyword_4_0());
                    			
                    // InternalTripDsl.g:533:4: ( (lv_cost_5_0= ruleEDouble ) )
                    // InternalTripDsl.g:534:5: (lv_cost_5_0= ruleEDouble )
                    {
                    // InternalTripDsl.g:534:5: (lv_cost_5_0= ruleEDouble )
                    // InternalTripDsl.g:535:6: lv_cost_5_0= ruleEDouble
                    {

                    						newCompositeNode(grammarAccess.getTransportServiceAccess().getCostEDoubleParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_14);
                    lv_cost_5_0=ruleEDouble();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getTransportServiceRule());
                    						}
                    						set(
                    							current,
                    							"cost",
                    							lv_cost_5_0,
                    							"org.xtext.example.mydsl.TripDsl.EDouble");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalTripDsl.g:553:3: (otherlv_6= 'type' ( ( (lv_type_7_1= 'Bus' | lv_type_7_2= 'Train' | lv_type_7_3= 'Plane' | lv_type_7_4= 'Car-rental' | lv_type_7_5= 'Bike' | lv_type_7_6= 'Taxi' ) ) ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==36) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalTripDsl.g:554:4: otherlv_6= 'type' ( ( (lv_type_7_1= 'Bus' | lv_type_7_2= 'Train' | lv_type_7_3= 'Plane' | lv_type_7_4= 'Car-rental' | lv_type_7_5= 'Bike' | lv_type_7_6= 'Taxi' ) ) )
                    {
                    otherlv_6=(Token)match(input,36,FOLLOW_15); 

                    				newLeafNode(otherlv_6, grammarAccess.getTransportServiceAccess().getTypeKeyword_5_0());
                    			
                    // InternalTripDsl.g:558:4: ( ( (lv_type_7_1= 'Bus' | lv_type_7_2= 'Train' | lv_type_7_3= 'Plane' | lv_type_7_4= 'Car-rental' | lv_type_7_5= 'Bike' | lv_type_7_6= 'Taxi' ) ) )
                    // InternalTripDsl.g:559:5: ( (lv_type_7_1= 'Bus' | lv_type_7_2= 'Train' | lv_type_7_3= 'Plane' | lv_type_7_4= 'Car-rental' | lv_type_7_5= 'Bike' | lv_type_7_6= 'Taxi' ) )
                    {
                    // InternalTripDsl.g:559:5: ( (lv_type_7_1= 'Bus' | lv_type_7_2= 'Train' | lv_type_7_3= 'Plane' | lv_type_7_4= 'Car-rental' | lv_type_7_5= 'Bike' | lv_type_7_6= 'Taxi' ) )
                    // InternalTripDsl.g:560:6: (lv_type_7_1= 'Bus' | lv_type_7_2= 'Train' | lv_type_7_3= 'Plane' | lv_type_7_4= 'Car-rental' | lv_type_7_5= 'Bike' | lv_type_7_6= 'Taxi' )
                    {
                    // InternalTripDsl.g:560:6: (lv_type_7_1= 'Bus' | lv_type_7_2= 'Train' | lv_type_7_3= 'Plane' | lv_type_7_4= 'Car-rental' | lv_type_7_5= 'Bike' | lv_type_7_6= 'Taxi' )
                    int alt10=6;
                    switch ( input.LA(1) ) {
                    case 37:
                        {
                        alt10=1;
                        }
                        break;
                    case 38:
                        {
                        alt10=2;
                        }
                        break;
                    case 39:
                        {
                        alt10=3;
                        }
                        break;
                    case 33:
                        {
                        alt10=4;
                        }
                        break;
                    case 40:
                        {
                        alt10=5;
                        }
                        break;
                    case 31:
                        {
                        alt10=6;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 10, 0, input);

                        throw nvae;
                    }

                    switch (alt10) {
                        case 1 :
                            // InternalTripDsl.g:561:7: lv_type_7_1= 'Bus'
                            {
                            lv_type_7_1=(Token)match(input,37,FOLLOW_16); 

                            							newLeafNode(lv_type_7_1, grammarAccess.getTransportServiceAccess().getTypeBusKeyword_5_1_0_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "type", lv_type_7_1, null);
                            						

                            }
                            break;
                        case 2 :
                            // InternalTripDsl.g:572:7: lv_type_7_2= 'Train'
                            {
                            lv_type_7_2=(Token)match(input,38,FOLLOW_16); 

                            							newLeafNode(lv_type_7_2, grammarAccess.getTransportServiceAccess().getTypeTrainKeyword_5_1_0_1());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "type", lv_type_7_2, null);
                            						

                            }
                            break;
                        case 3 :
                            // InternalTripDsl.g:583:7: lv_type_7_3= 'Plane'
                            {
                            lv_type_7_3=(Token)match(input,39,FOLLOW_16); 

                            							newLeafNode(lv_type_7_3, grammarAccess.getTransportServiceAccess().getTypePlaneKeyword_5_1_0_2());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "type", lv_type_7_3, null);
                            						

                            }
                            break;
                        case 4 :
                            // InternalTripDsl.g:594:7: lv_type_7_4= 'Car-rental'
                            {
                            lv_type_7_4=(Token)match(input,33,FOLLOW_16); 

                            							newLeafNode(lv_type_7_4, grammarAccess.getTransportServiceAccess().getTypeCarRentalKeyword_5_1_0_3());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "type", lv_type_7_4, null);
                            						

                            }
                            break;
                        case 5 :
                            // InternalTripDsl.g:605:7: lv_type_7_5= 'Bike'
                            {
                            lv_type_7_5=(Token)match(input,40,FOLLOW_16); 

                            							newLeafNode(lv_type_7_5, grammarAccess.getTransportServiceAccess().getTypeBikeKeyword_5_1_0_4());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "type", lv_type_7_5, null);
                            						

                            }
                            break;
                        case 6 :
                            // InternalTripDsl.g:616:7: lv_type_7_6= 'Taxi'
                            {
                            lv_type_7_6=(Token)match(input,31,FOLLOW_16); 

                            							newLeafNode(lv_type_7_6, grammarAccess.getTransportServiceAccess().getTypeTaxiKeyword_5_1_0_5());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "type", lv_type_7_6, null);
                            						

                            }
                            break;

                    }


                    }


                    }


                    }
                    break;

            }

            // InternalTripDsl.g:630:3: (otherlv_8= 'source-city' ( ( (lv_srce_9_1= 'London' | lv_srce_9_2= 'Paris' | lv_srce_9_3= 'Nice' | lv_srce_9_4= 'Humburg' | lv_srce_9_5= 'Berlin' | lv_srce_9_6= 'Texas' | lv_srce_9_7= 'Rome' | lv_srce_9_8= 'Moscow' | lv_srce_9_9= 'Abuja' ) ) ) )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==41) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalTripDsl.g:631:4: otherlv_8= 'source-city' ( ( (lv_srce_9_1= 'London' | lv_srce_9_2= 'Paris' | lv_srce_9_3= 'Nice' | lv_srce_9_4= 'Humburg' | lv_srce_9_5= 'Berlin' | lv_srce_9_6= 'Texas' | lv_srce_9_7= 'Rome' | lv_srce_9_8= 'Moscow' | lv_srce_9_9= 'Abuja' ) ) )
                    {
                    otherlv_8=(Token)match(input,41,FOLLOW_5); 

                    				newLeafNode(otherlv_8, grammarAccess.getTransportServiceAccess().getSourceCityKeyword_6_0());
                    			
                    // InternalTripDsl.g:635:4: ( ( (lv_srce_9_1= 'London' | lv_srce_9_2= 'Paris' | lv_srce_9_3= 'Nice' | lv_srce_9_4= 'Humburg' | lv_srce_9_5= 'Berlin' | lv_srce_9_6= 'Texas' | lv_srce_9_7= 'Rome' | lv_srce_9_8= 'Moscow' | lv_srce_9_9= 'Abuja' ) ) )
                    // InternalTripDsl.g:636:5: ( (lv_srce_9_1= 'London' | lv_srce_9_2= 'Paris' | lv_srce_9_3= 'Nice' | lv_srce_9_4= 'Humburg' | lv_srce_9_5= 'Berlin' | lv_srce_9_6= 'Texas' | lv_srce_9_7= 'Rome' | lv_srce_9_8= 'Moscow' | lv_srce_9_9= 'Abuja' ) )
                    {
                    // InternalTripDsl.g:636:5: ( (lv_srce_9_1= 'London' | lv_srce_9_2= 'Paris' | lv_srce_9_3= 'Nice' | lv_srce_9_4= 'Humburg' | lv_srce_9_5= 'Berlin' | lv_srce_9_6= 'Texas' | lv_srce_9_7= 'Rome' | lv_srce_9_8= 'Moscow' | lv_srce_9_9= 'Abuja' ) )
                    // InternalTripDsl.g:637:6: (lv_srce_9_1= 'London' | lv_srce_9_2= 'Paris' | lv_srce_9_3= 'Nice' | lv_srce_9_4= 'Humburg' | lv_srce_9_5= 'Berlin' | lv_srce_9_6= 'Texas' | lv_srce_9_7= 'Rome' | lv_srce_9_8= 'Moscow' | lv_srce_9_9= 'Abuja' )
                    {
                    // InternalTripDsl.g:637:6: (lv_srce_9_1= 'London' | lv_srce_9_2= 'Paris' | lv_srce_9_3= 'Nice' | lv_srce_9_4= 'Humburg' | lv_srce_9_5= 'Berlin' | lv_srce_9_6= 'Texas' | lv_srce_9_7= 'Rome' | lv_srce_9_8= 'Moscow' | lv_srce_9_9= 'Abuja' )
                    int alt12=9;
                    switch ( input.LA(1) ) {
                    case 14:
                        {
                        alt12=1;
                        }
                        break;
                    case 15:
                        {
                        alt12=2;
                        }
                        break;
                    case 16:
                        {
                        alt12=3;
                        }
                        break;
                    case 17:
                        {
                        alt12=4;
                        }
                        break;
                    case 18:
                        {
                        alt12=5;
                        }
                        break;
                    case 19:
                        {
                        alt12=6;
                        }
                        break;
                    case 20:
                        {
                        alt12=7;
                        }
                        break;
                    case 21:
                        {
                        alt12=8;
                        }
                        break;
                    case 22:
                        {
                        alt12=9;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 12, 0, input);

                        throw nvae;
                    }

                    switch (alt12) {
                        case 1 :
                            // InternalTripDsl.g:638:7: lv_srce_9_1= 'London'
                            {
                            lv_srce_9_1=(Token)match(input,14,FOLLOW_17); 

                            							newLeafNode(lv_srce_9_1, grammarAccess.getTransportServiceAccess().getSrceLondonKeyword_6_1_0_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "srce", lv_srce_9_1, null);
                            						

                            }
                            break;
                        case 2 :
                            // InternalTripDsl.g:649:7: lv_srce_9_2= 'Paris'
                            {
                            lv_srce_9_2=(Token)match(input,15,FOLLOW_17); 

                            							newLeafNode(lv_srce_9_2, grammarAccess.getTransportServiceAccess().getSrceParisKeyword_6_1_0_1());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "srce", lv_srce_9_2, null);
                            						

                            }
                            break;
                        case 3 :
                            // InternalTripDsl.g:660:7: lv_srce_9_3= 'Nice'
                            {
                            lv_srce_9_3=(Token)match(input,16,FOLLOW_17); 

                            							newLeafNode(lv_srce_9_3, grammarAccess.getTransportServiceAccess().getSrceNiceKeyword_6_1_0_2());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "srce", lv_srce_9_3, null);
                            						

                            }
                            break;
                        case 4 :
                            // InternalTripDsl.g:671:7: lv_srce_9_4= 'Humburg'
                            {
                            lv_srce_9_4=(Token)match(input,17,FOLLOW_17); 

                            							newLeafNode(lv_srce_9_4, grammarAccess.getTransportServiceAccess().getSrceHumburgKeyword_6_1_0_3());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "srce", lv_srce_9_4, null);
                            						

                            }
                            break;
                        case 5 :
                            // InternalTripDsl.g:682:7: lv_srce_9_5= 'Berlin'
                            {
                            lv_srce_9_5=(Token)match(input,18,FOLLOW_17); 

                            							newLeafNode(lv_srce_9_5, grammarAccess.getTransportServiceAccess().getSrceBerlinKeyword_6_1_0_4());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "srce", lv_srce_9_5, null);
                            						

                            }
                            break;
                        case 6 :
                            // InternalTripDsl.g:693:7: lv_srce_9_6= 'Texas'
                            {
                            lv_srce_9_6=(Token)match(input,19,FOLLOW_17); 

                            							newLeafNode(lv_srce_9_6, grammarAccess.getTransportServiceAccess().getSrceTexasKeyword_6_1_0_5());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "srce", lv_srce_9_6, null);
                            						

                            }
                            break;
                        case 7 :
                            // InternalTripDsl.g:704:7: lv_srce_9_7= 'Rome'
                            {
                            lv_srce_9_7=(Token)match(input,20,FOLLOW_17); 

                            							newLeafNode(lv_srce_9_7, grammarAccess.getTransportServiceAccess().getSrceRomeKeyword_6_1_0_6());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "srce", lv_srce_9_7, null);
                            						

                            }
                            break;
                        case 8 :
                            // InternalTripDsl.g:715:7: lv_srce_9_8= 'Moscow'
                            {
                            lv_srce_9_8=(Token)match(input,21,FOLLOW_17); 

                            							newLeafNode(lv_srce_9_8, grammarAccess.getTransportServiceAccess().getSrceMoscowKeyword_6_1_0_7());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "srce", lv_srce_9_8, null);
                            						

                            }
                            break;
                        case 9 :
                            // InternalTripDsl.g:726:7: lv_srce_9_9= 'Abuja'
                            {
                            lv_srce_9_9=(Token)match(input,22,FOLLOW_17); 

                            							newLeafNode(lv_srce_9_9, grammarAccess.getTransportServiceAccess().getSrceAbujaKeyword_6_1_0_8());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "srce", lv_srce_9_9, null);
                            						

                            }
                            break;

                    }


                    }


                    }


                    }
                    break;

            }

            // InternalTripDsl.g:740:3: (otherlv_10= 'destination-city' ( ( (lv_dest_11_1= 'London' | lv_dest_11_2= 'Paris' | lv_dest_11_3= 'Nice' | lv_dest_11_4= 'Humburg' | lv_dest_11_5= 'Berlin' | lv_dest_11_6= 'Texas' | lv_dest_11_7= 'Rome' | lv_dest_11_8= 'Moscow' | lv_dest_11_9= 'Abuja' ) ) ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==42) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalTripDsl.g:741:4: otherlv_10= 'destination-city' ( ( (lv_dest_11_1= 'London' | lv_dest_11_2= 'Paris' | lv_dest_11_3= 'Nice' | lv_dest_11_4= 'Humburg' | lv_dest_11_5= 'Berlin' | lv_dest_11_6= 'Texas' | lv_dest_11_7= 'Rome' | lv_dest_11_8= 'Moscow' | lv_dest_11_9= 'Abuja' ) ) )
                    {
                    otherlv_10=(Token)match(input,42,FOLLOW_5); 

                    				newLeafNode(otherlv_10, grammarAccess.getTransportServiceAccess().getDestinationCityKeyword_7_0());
                    			
                    // InternalTripDsl.g:745:4: ( ( (lv_dest_11_1= 'London' | lv_dest_11_2= 'Paris' | lv_dest_11_3= 'Nice' | lv_dest_11_4= 'Humburg' | lv_dest_11_5= 'Berlin' | lv_dest_11_6= 'Texas' | lv_dest_11_7= 'Rome' | lv_dest_11_8= 'Moscow' | lv_dest_11_9= 'Abuja' ) ) )
                    // InternalTripDsl.g:746:5: ( (lv_dest_11_1= 'London' | lv_dest_11_2= 'Paris' | lv_dest_11_3= 'Nice' | lv_dest_11_4= 'Humburg' | lv_dest_11_5= 'Berlin' | lv_dest_11_6= 'Texas' | lv_dest_11_7= 'Rome' | lv_dest_11_8= 'Moscow' | lv_dest_11_9= 'Abuja' ) )
                    {
                    // InternalTripDsl.g:746:5: ( (lv_dest_11_1= 'London' | lv_dest_11_2= 'Paris' | lv_dest_11_3= 'Nice' | lv_dest_11_4= 'Humburg' | lv_dest_11_5= 'Berlin' | lv_dest_11_6= 'Texas' | lv_dest_11_7= 'Rome' | lv_dest_11_8= 'Moscow' | lv_dest_11_9= 'Abuja' ) )
                    // InternalTripDsl.g:747:6: (lv_dest_11_1= 'London' | lv_dest_11_2= 'Paris' | lv_dest_11_3= 'Nice' | lv_dest_11_4= 'Humburg' | lv_dest_11_5= 'Berlin' | lv_dest_11_6= 'Texas' | lv_dest_11_7= 'Rome' | lv_dest_11_8= 'Moscow' | lv_dest_11_9= 'Abuja' )
                    {
                    // InternalTripDsl.g:747:6: (lv_dest_11_1= 'London' | lv_dest_11_2= 'Paris' | lv_dest_11_3= 'Nice' | lv_dest_11_4= 'Humburg' | lv_dest_11_5= 'Berlin' | lv_dest_11_6= 'Texas' | lv_dest_11_7= 'Rome' | lv_dest_11_8= 'Moscow' | lv_dest_11_9= 'Abuja' )
                    int alt14=9;
                    switch ( input.LA(1) ) {
                    case 14:
                        {
                        alt14=1;
                        }
                        break;
                    case 15:
                        {
                        alt14=2;
                        }
                        break;
                    case 16:
                        {
                        alt14=3;
                        }
                        break;
                    case 17:
                        {
                        alt14=4;
                        }
                        break;
                    case 18:
                        {
                        alt14=5;
                        }
                        break;
                    case 19:
                        {
                        alt14=6;
                        }
                        break;
                    case 20:
                        {
                        alt14=7;
                        }
                        break;
                    case 21:
                        {
                        alt14=8;
                        }
                        break;
                    case 22:
                        {
                        alt14=9;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 14, 0, input);

                        throw nvae;
                    }

                    switch (alt14) {
                        case 1 :
                            // InternalTripDsl.g:748:7: lv_dest_11_1= 'London'
                            {
                            lv_dest_11_1=(Token)match(input,14,FOLLOW_10); 

                            							newLeafNode(lv_dest_11_1, grammarAccess.getTransportServiceAccess().getDestLondonKeyword_7_1_0_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "dest", lv_dest_11_1, null);
                            						

                            }
                            break;
                        case 2 :
                            // InternalTripDsl.g:759:7: lv_dest_11_2= 'Paris'
                            {
                            lv_dest_11_2=(Token)match(input,15,FOLLOW_10); 

                            							newLeafNode(lv_dest_11_2, grammarAccess.getTransportServiceAccess().getDestParisKeyword_7_1_0_1());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "dest", lv_dest_11_2, null);
                            						

                            }
                            break;
                        case 3 :
                            // InternalTripDsl.g:770:7: lv_dest_11_3= 'Nice'
                            {
                            lv_dest_11_3=(Token)match(input,16,FOLLOW_10); 

                            							newLeafNode(lv_dest_11_3, grammarAccess.getTransportServiceAccess().getDestNiceKeyword_7_1_0_2());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "dest", lv_dest_11_3, null);
                            						

                            }
                            break;
                        case 4 :
                            // InternalTripDsl.g:781:7: lv_dest_11_4= 'Humburg'
                            {
                            lv_dest_11_4=(Token)match(input,17,FOLLOW_10); 

                            							newLeafNode(lv_dest_11_4, grammarAccess.getTransportServiceAccess().getDestHumburgKeyword_7_1_0_3());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "dest", lv_dest_11_4, null);
                            						

                            }
                            break;
                        case 5 :
                            // InternalTripDsl.g:792:7: lv_dest_11_5= 'Berlin'
                            {
                            lv_dest_11_5=(Token)match(input,18,FOLLOW_10); 

                            							newLeafNode(lv_dest_11_5, grammarAccess.getTransportServiceAccess().getDestBerlinKeyword_7_1_0_4());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "dest", lv_dest_11_5, null);
                            						

                            }
                            break;
                        case 6 :
                            // InternalTripDsl.g:803:7: lv_dest_11_6= 'Texas'
                            {
                            lv_dest_11_6=(Token)match(input,19,FOLLOW_10); 

                            							newLeafNode(lv_dest_11_6, grammarAccess.getTransportServiceAccess().getDestTexasKeyword_7_1_0_5());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "dest", lv_dest_11_6, null);
                            						

                            }
                            break;
                        case 7 :
                            // InternalTripDsl.g:814:7: lv_dest_11_7= 'Rome'
                            {
                            lv_dest_11_7=(Token)match(input,20,FOLLOW_10); 

                            							newLeafNode(lv_dest_11_7, grammarAccess.getTransportServiceAccess().getDestRomeKeyword_7_1_0_6());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "dest", lv_dest_11_7, null);
                            						

                            }
                            break;
                        case 8 :
                            // InternalTripDsl.g:825:7: lv_dest_11_8= 'Moscow'
                            {
                            lv_dest_11_8=(Token)match(input,21,FOLLOW_10); 

                            							newLeafNode(lv_dest_11_8, grammarAccess.getTransportServiceAccess().getDestMoscowKeyword_7_1_0_7());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "dest", lv_dest_11_8, null);
                            						

                            }
                            break;
                        case 9 :
                            // InternalTripDsl.g:836:7: lv_dest_11_9= 'Abuja'
                            {
                            lv_dest_11_9=(Token)match(input,22,FOLLOW_10); 

                            							newLeafNode(lv_dest_11_9, grammarAccess.getTransportServiceAccess().getDestAbujaKeyword_7_1_0_8());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getTransportServiceRule());
                            							}
                            							setWithLastConsumed(current, "dest", lv_dest_11_9, null);
                            						

                            }
                            break;

                    }


                    }


                    }


                    }
                    break;

            }

            otherlv_12=(Token)match(input,26,FOLLOW_2); 

            			newLeafNode(otherlv_12, grammarAccess.getTransportServiceAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTransportService"


    // $ANTLR start "entryRuleLocalService"
    // InternalTripDsl.g:858:1: entryRuleLocalService returns [EObject current=null] : iv_ruleLocalService= ruleLocalService EOF ;
    public final EObject entryRuleLocalService() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLocalService = null;


        try {
            // InternalTripDsl.g:858:53: (iv_ruleLocalService= ruleLocalService EOF )
            // InternalTripDsl.g:859:2: iv_ruleLocalService= ruleLocalService EOF
            {
             newCompositeNode(grammarAccess.getLocalServiceRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLocalService=ruleLocalService();

            state._fsp--;

             current =iv_ruleLocalService; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLocalService"


    // $ANTLR start "ruleLocalService"
    // InternalTripDsl.g:865:1: ruleLocalService returns [EObject current=null] : ( () otherlv_1= 'LocalService' ( ( (lv_name_2_1= 'Api' | lv_name_2_2= 'B&B-Hotel' | lv_name_2_3= 'Novotel' | lv_name_2_4= 'Generator' | lv_name_2_5= 'Le-Grand-Cafe' ) ) ) otherlv_3= '{' (otherlv_4= 'cost' ( (lv_cost_5_0= ruleEDouble ) ) )? (otherlv_6= 'location' ( ( (lv_location_7_1= 'London' | lv_location_7_2= 'Paris' | lv_location_7_3= 'Nice' | lv_location_7_4= 'Humburg' | lv_location_7_5= 'Berlin' | lv_location_7_6= 'Texas' | lv_location_7_7= 'Rome' | lv_location_7_8= 'Moscow' | lv_location_7_9= 'Abuja' ) ) ) )? (otherlv_8= 'type' ( ( (lv_type_9_1= 'Restaurant' | lv_type_9_2= 'Hotel' ) ) ) )? otherlv_10= '}' ) ;
    public final EObject ruleLocalService() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token lv_name_2_1=null;
        Token lv_name_2_2=null;
        Token lv_name_2_3=null;
        Token lv_name_2_4=null;
        Token lv_name_2_5=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token lv_location_7_1=null;
        Token lv_location_7_2=null;
        Token lv_location_7_3=null;
        Token lv_location_7_4=null;
        Token lv_location_7_5=null;
        Token lv_location_7_6=null;
        Token lv_location_7_7=null;
        Token lv_location_7_8=null;
        Token lv_location_7_9=null;
        Token otherlv_8=null;
        Token lv_type_9_1=null;
        Token lv_type_9_2=null;
        Token otherlv_10=null;
        AntlrDatatypeRuleToken lv_cost_5_0 = null;



        	enterRule();

        try {
            // InternalTripDsl.g:871:2: ( ( () otherlv_1= 'LocalService' ( ( (lv_name_2_1= 'Api' | lv_name_2_2= 'B&B-Hotel' | lv_name_2_3= 'Novotel' | lv_name_2_4= 'Generator' | lv_name_2_5= 'Le-Grand-Cafe' ) ) ) otherlv_3= '{' (otherlv_4= 'cost' ( (lv_cost_5_0= ruleEDouble ) ) )? (otherlv_6= 'location' ( ( (lv_location_7_1= 'London' | lv_location_7_2= 'Paris' | lv_location_7_3= 'Nice' | lv_location_7_4= 'Humburg' | lv_location_7_5= 'Berlin' | lv_location_7_6= 'Texas' | lv_location_7_7= 'Rome' | lv_location_7_8= 'Moscow' | lv_location_7_9= 'Abuja' ) ) ) )? (otherlv_8= 'type' ( ( (lv_type_9_1= 'Restaurant' | lv_type_9_2= 'Hotel' ) ) ) )? otherlv_10= '}' ) )
            // InternalTripDsl.g:872:2: ( () otherlv_1= 'LocalService' ( ( (lv_name_2_1= 'Api' | lv_name_2_2= 'B&B-Hotel' | lv_name_2_3= 'Novotel' | lv_name_2_4= 'Generator' | lv_name_2_5= 'Le-Grand-Cafe' ) ) ) otherlv_3= '{' (otherlv_4= 'cost' ( (lv_cost_5_0= ruleEDouble ) ) )? (otherlv_6= 'location' ( ( (lv_location_7_1= 'London' | lv_location_7_2= 'Paris' | lv_location_7_3= 'Nice' | lv_location_7_4= 'Humburg' | lv_location_7_5= 'Berlin' | lv_location_7_6= 'Texas' | lv_location_7_7= 'Rome' | lv_location_7_8= 'Moscow' | lv_location_7_9= 'Abuja' ) ) ) )? (otherlv_8= 'type' ( ( (lv_type_9_1= 'Restaurant' | lv_type_9_2= 'Hotel' ) ) ) )? otherlv_10= '}' )
            {
            // InternalTripDsl.g:872:2: ( () otherlv_1= 'LocalService' ( ( (lv_name_2_1= 'Api' | lv_name_2_2= 'B&B-Hotel' | lv_name_2_3= 'Novotel' | lv_name_2_4= 'Generator' | lv_name_2_5= 'Le-Grand-Cafe' ) ) ) otherlv_3= '{' (otherlv_4= 'cost' ( (lv_cost_5_0= ruleEDouble ) ) )? (otherlv_6= 'location' ( ( (lv_location_7_1= 'London' | lv_location_7_2= 'Paris' | lv_location_7_3= 'Nice' | lv_location_7_4= 'Humburg' | lv_location_7_5= 'Berlin' | lv_location_7_6= 'Texas' | lv_location_7_7= 'Rome' | lv_location_7_8= 'Moscow' | lv_location_7_9= 'Abuja' ) ) ) )? (otherlv_8= 'type' ( ( (lv_type_9_1= 'Restaurant' | lv_type_9_2= 'Hotel' ) ) ) )? otherlv_10= '}' )
            // InternalTripDsl.g:873:3: () otherlv_1= 'LocalService' ( ( (lv_name_2_1= 'Api' | lv_name_2_2= 'B&B-Hotel' | lv_name_2_3= 'Novotel' | lv_name_2_4= 'Generator' | lv_name_2_5= 'Le-Grand-Cafe' ) ) ) otherlv_3= '{' (otherlv_4= 'cost' ( (lv_cost_5_0= ruleEDouble ) ) )? (otherlv_6= 'location' ( ( (lv_location_7_1= 'London' | lv_location_7_2= 'Paris' | lv_location_7_3= 'Nice' | lv_location_7_4= 'Humburg' | lv_location_7_5= 'Berlin' | lv_location_7_6= 'Texas' | lv_location_7_7= 'Rome' | lv_location_7_8= 'Moscow' | lv_location_7_9= 'Abuja' ) ) ) )? (otherlv_8= 'type' ( ( (lv_type_9_1= 'Restaurant' | lv_type_9_2= 'Hotel' ) ) ) )? otherlv_10= '}'
            {
            // InternalTripDsl.g:873:3: ()
            // InternalTripDsl.g:874:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getLocalServiceAccess().getLocalServiceAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,43,FOLLOW_18); 

            			newLeafNode(otherlv_1, grammarAccess.getLocalServiceAccess().getLocalServiceKeyword_1());
            		
            // InternalTripDsl.g:884:3: ( ( (lv_name_2_1= 'Api' | lv_name_2_2= 'B&B-Hotel' | lv_name_2_3= 'Novotel' | lv_name_2_4= 'Generator' | lv_name_2_5= 'Le-Grand-Cafe' ) ) )
            // InternalTripDsl.g:885:4: ( (lv_name_2_1= 'Api' | lv_name_2_2= 'B&B-Hotel' | lv_name_2_3= 'Novotel' | lv_name_2_4= 'Generator' | lv_name_2_5= 'Le-Grand-Cafe' ) )
            {
            // InternalTripDsl.g:885:4: ( (lv_name_2_1= 'Api' | lv_name_2_2= 'B&B-Hotel' | lv_name_2_3= 'Novotel' | lv_name_2_4= 'Generator' | lv_name_2_5= 'Le-Grand-Cafe' ) )
            // InternalTripDsl.g:886:5: (lv_name_2_1= 'Api' | lv_name_2_2= 'B&B-Hotel' | lv_name_2_3= 'Novotel' | lv_name_2_4= 'Generator' | lv_name_2_5= 'Le-Grand-Cafe' )
            {
            // InternalTripDsl.g:886:5: (lv_name_2_1= 'Api' | lv_name_2_2= 'B&B-Hotel' | lv_name_2_3= 'Novotel' | lv_name_2_4= 'Generator' | lv_name_2_5= 'Le-Grand-Cafe' )
            int alt16=5;
            switch ( input.LA(1) ) {
            case 44:
                {
                alt16=1;
                }
                break;
            case 45:
                {
                alt16=2;
                }
                break;
            case 46:
                {
                alt16=3;
                }
                break;
            case 47:
                {
                alt16=4;
                }
                break;
            case 48:
                {
                alt16=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }

            switch (alt16) {
                case 1 :
                    // InternalTripDsl.g:887:6: lv_name_2_1= 'Api'
                    {
                    lv_name_2_1=(Token)match(input,44,FOLLOW_3); 

                    						newLeafNode(lv_name_2_1, grammarAccess.getLocalServiceAccess().getNameApiKeyword_2_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLocalServiceRule());
                    						}
                    						setWithLastConsumed(current, "name", lv_name_2_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalTripDsl.g:898:6: lv_name_2_2= 'B&B-Hotel'
                    {
                    lv_name_2_2=(Token)match(input,45,FOLLOW_3); 

                    						newLeafNode(lv_name_2_2, grammarAccess.getLocalServiceAccess().getNameBBHotelKeyword_2_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLocalServiceRule());
                    						}
                    						setWithLastConsumed(current, "name", lv_name_2_2, null);
                    					

                    }
                    break;
                case 3 :
                    // InternalTripDsl.g:909:6: lv_name_2_3= 'Novotel'
                    {
                    lv_name_2_3=(Token)match(input,46,FOLLOW_3); 

                    						newLeafNode(lv_name_2_3, grammarAccess.getLocalServiceAccess().getNameNovotelKeyword_2_0_2());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLocalServiceRule());
                    						}
                    						setWithLastConsumed(current, "name", lv_name_2_3, null);
                    					

                    }
                    break;
                case 4 :
                    // InternalTripDsl.g:920:6: lv_name_2_4= 'Generator'
                    {
                    lv_name_2_4=(Token)match(input,47,FOLLOW_3); 

                    						newLeafNode(lv_name_2_4, grammarAccess.getLocalServiceAccess().getNameGeneratorKeyword_2_0_3());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLocalServiceRule());
                    						}
                    						setWithLastConsumed(current, "name", lv_name_2_4, null);
                    					

                    }
                    break;
                case 5 :
                    // InternalTripDsl.g:931:6: lv_name_2_5= 'Le-Grand-Cafe'
                    {
                    lv_name_2_5=(Token)match(input,48,FOLLOW_3); 

                    						newLeafNode(lv_name_2_5, grammarAccess.getLocalServiceAccess().getNameLeGrandCafeKeyword_2_0_4());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLocalServiceRule());
                    						}
                    						setWithLastConsumed(current, "name", lv_name_2_5, null);
                    					

                    }
                    break;

            }


            }


            }

            otherlv_3=(Token)match(input,12,FOLLOW_19); 

            			newLeafNode(otherlv_3, grammarAccess.getLocalServiceAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalTripDsl.g:948:3: (otherlv_4= 'cost' ( (lv_cost_5_0= ruleEDouble ) ) )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==35) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalTripDsl.g:949:4: otherlv_4= 'cost' ( (lv_cost_5_0= ruleEDouble ) )
                    {
                    otherlv_4=(Token)match(input,35,FOLLOW_13); 

                    				newLeafNode(otherlv_4, grammarAccess.getLocalServiceAccess().getCostKeyword_4_0());
                    			
                    // InternalTripDsl.g:953:4: ( (lv_cost_5_0= ruleEDouble ) )
                    // InternalTripDsl.g:954:5: (lv_cost_5_0= ruleEDouble )
                    {
                    // InternalTripDsl.g:954:5: (lv_cost_5_0= ruleEDouble )
                    // InternalTripDsl.g:955:6: lv_cost_5_0= ruleEDouble
                    {

                    						newCompositeNode(grammarAccess.getLocalServiceAccess().getCostEDoubleParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_20);
                    lv_cost_5_0=ruleEDouble();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getLocalServiceRule());
                    						}
                    						set(
                    							current,
                    							"cost",
                    							lv_cost_5_0,
                    							"org.xtext.example.mydsl.TripDsl.EDouble");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalTripDsl.g:973:3: (otherlv_6= 'location' ( ( (lv_location_7_1= 'London' | lv_location_7_2= 'Paris' | lv_location_7_3= 'Nice' | lv_location_7_4= 'Humburg' | lv_location_7_5= 'Berlin' | lv_location_7_6= 'Texas' | lv_location_7_7= 'Rome' | lv_location_7_8= 'Moscow' | lv_location_7_9= 'Abuja' ) ) ) )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==49) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalTripDsl.g:974:4: otherlv_6= 'location' ( ( (lv_location_7_1= 'London' | lv_location_7_2= 'Paris' | lv_location_7_3= 'Nice' | lv_location_7_4= 'Humburg' | lv_location_7_5= 'Berlin' | lv_location_7_6= 'Texas' | lv_location_7_7= 'Rome' | lv_location_7_8= 'Moscow' | lv_location_7_9= 'Abuja' ) ) )
                    {
                    otherlv_6=(Token)match(input,49,FOLLOW_5); 

                    				newLeafNode(otherlv_6, grammarAccess.getLocalServiceAccess().getLocationKeyword_5_0());
                    			
                    // InternalTripDsl.g:978:4: ( ( (lv_location_7_1= 'London' | lv_location_7_2= 'Paris' | lv_location_7_3= 'Nice' | lv_location_7_4= 'Humburg' | lv_location_7_5= 'Berlin' | lv_location_7_6= 'Texas' | lv_location_7_7= 'Rome' | lv_location_7_8= 'Moscow' | lv_location_7_9= 'Abuja' ) ) )
                    // InternalTripDsl.g:979:5: ( (lv_location_7_1= 'London' | lv_location_7_2= 'Paris' | lv_location_7_3= 'Nice' | lv_location_7_4= 'Humburg' | lv_location_7_5= 'Berlin' | lv_location_7_6= 'Texas' | lv_location_7_7= 'Rome' | lv_location_7_8= 'Moscow' | lv_location_7_9= 'Abuja' ) )
                    {
                    // InternalTripDsl.g:979:5: ( (lv_location_7_1= 'London' | lv_location_7_2= 'Paris' | lv_location_7_3= 'Nice' | lv_location_7_4= 'Humburg' | lv_location_7_5= 'Berlin' | lv_location_7_6= 'Texas' | lv_location_7_7= 'Rome' | lv_location_7_8= 'Moscow' | lv_location_7_9= 'Abuja' ) )
                    // InternalTripDsl.g:980:6: (lv_location_7_1= 'London' | lv_location_7_2= 'Paris' | lv_location_7_3= 'Nice' | lv_location_7_4= 'Humburg' | lv_location_7_5= 'Berlin' | lv_location_7_6= 'Texas' | lv_location_7_7= 'Rome' | lv_location_7_8= 'Moscow' | lv_location_7_9= 'Abuja' )
                    {
                    // InternalTripDsl.g:980:6: (lv_location_7_1= 'London' | lv_location_7_2= 'Paris' | lv_location_7_3= 'Nice' | lv_location_7_4= 'Humburg' | lv_location_7_5= 'Berlin' | lv_location_7_6= 'Texas' | lv_location_7_7= 'Rome' | lv_location_7_8= 'Moscow' | lv_location_7_9= 'Abuja' )
                    int alt18=9;
                    switch ( input.LA(1) ) {
                    case 14:
                        {
                        alt18=1;
                        }
                        break;
                    case 15:
                        {
                        alt18=2;
                        }
                        break;
                    case 16:
                        {
                        alt18=3;
                        }
                        break;
                    case 17:
                        {
                        alt18=4;
                        }
                        break;
                    case 18:
                        {
                        alt18=5;
                        }
                        break;
                    case 19:
                        {
                        alt18=6;
                        }
                        break;
                    case 20:
                        {
                        alt18=7;
                        }
                        break;
                    case 21:
                        {
                        alt18=8;
                        }
                        break;
                    case 22:
                        {
                        alt18=9;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 18, 0, input);

                        throw nvae;
                    }

                    switch (alt18) {
                        case 1 :
                            // InternalTripDsl.g:981:7: lv_location_7_1= 'London'
                            {
                            lv_location_7_1=(Token)match(input,14,FOLLOW_21); 

                            							newLeafNode(lv_location_7_1, grammarAccess.getLocalServiceAccess().getLocationLondonKeyword_5_1_0_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getLocalServiceRule());
                            							}
                            							setWithLastConsumed(current, "location", lv_location_7_1, null);
                            						

                            }
                            break;
                        case 2 :
                            // InternalTripDsl.g:992:7: lv_location_7_2= 'Paris'
                            {
                            lv_location_7_2=(Token)match(input,15,FOLLOW_21); 

                            							newLeafNode(lv_location_7_2, grammarAccess.getLocalServiceAccess().getLocationParisKeyword_5_1_0_1());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getLocalServiceRule());
                            							}
                            							setWithLastConsumed(current, "location", lv_location_7_2, null);
                            						

                            }
                            break;
                        case 3 :
                            // InternalTripDsl.g:1003:7: lv_location_7_3= 'Nice'
                            {
                            lv_location_7_3=(Token)match(input,16,FOLLOW_21); 

                            							newLeafNode(lv_location_7_3, grammarAccess.getLocalServiceAccess().getLocationNiceKeyword_5_1_0_2());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getLocalServiceRule());
                            							}
                            							setWithLastConsumed(current, "location", lv_location_7_3, null);
                            						

                            }
                            break;
                        case 4 :
                            // InternalTripDsl.g:1014:7: lv_location_7_4= 'Humburg'
                            {
                            lv_location_7_4=(Token)match(input,17,FOLLOW_21); 

                            							newLeafNode(lv_location_7_4, grammarAccess.getLocalServiceAccess().getLocationHumburgKeyword_5_1_0_3());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getLocalServiceRule());
                            							}
                            							setWithLastConsumed(current, "location", lv_location_7_4, null);
                            						

                            }
                            break;
                        case 5 :
                            // InternalTripDsl.g:1025:7: lv_location_7_5= 'Berlin'
                            {
                            lv_location_7_5=(Token)match(input,18,FOLLOW_21); 

                            							newLeafNode(lv_location_7_5, grammarAccess.getLocalServiceAccess().getLocationBerlinKeyword_5_1_0_4());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getLocalServiceRule());
                            							}
                            							setWithLastConsumed(current, "location", lv_location_7_5, null);
                            						

                            }
                            break;
                        case 6 :
                            // InternalTripDsl.g:1036:7: lv_location_7_6= 'Texas'
                            {
                            lv_location_7_6=(Token)match(input,19,FOLLOW_21); 

                            							newLeafNode(lv_location_7_6, grammarAccess.getLocalServiceAccess().getLocationTexasKeyword_5_1_0_5());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getLocalServiceRule());
                            							}
                            							setWithLastConsumed(current, "location", lv_location_7_6, null);
                            						

                            }
                            break;
                        case 7 :
                            // InternalTripDsl.g:1047:7: lv_location_7_7= 'Rome'
                            {
                            lv_location_7_7=(Token)match(input,20,FOLLOW_21); 

                            							newLeafNode(lv_location_7_7, grammarAccess.getLocalServiceAccess().getLocationRomeKeyword_5_1_0_6());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getLocalServiceRule());
                            							}
                            							setWithLastConsumed(current, "location", lv_location_7_7, null);
                            						

                            }
                            break;
                        case 8 :
                            // InternalTripDsl.g:1058:7: lv_location_7_8= 'Moscow'
                            {
                            lv_location_7_8=(Token)match(input,21,FOLLOW_21); 

                            							newLeafNode(lv_location_7_8, grammarAccess.getLocalServiceAccess().getLocationMoscowKeyword_5_1_0_7());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getLocalServiceRule());
                            							}
                            							setWithLastConsumed(current, "location", lv_location_7_8, null);
                            						

                            }
                            break;
                        case 9 :
                            // InternalTripDsl.g:1069:7: lv_location_7_9= 'Abuja'
                            {
                            lv_location_7_9=(Token)match(input,22,FOLLOW_21); 

                            							newLeafNode(lv_location_7_9, grammarAccess.getLocalServiceAccess().getLocationAbujaKeyword_5_1_0_8());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getLocalServiceRule());
                            							}
                            							setWithLastConsumed(current, "location", lv_location_7_9, null);
                            						

                            }
                            break;

                    }


                    }


                    }


                    }
                    break;

            }

            // InternalTripDsl.g:1083:3: (otherlv_8= 'type' ( ( (lv_type_9_1= 'Restaurant' | lv_type_9_2= 'Hotel' ) ) ) )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==36) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // InternalTripDsl.g:1084:4: otherlv_8= 'type' ( ( (lv_type_9_1= 'Restaurant' | lv_type_9_2= 'Hotel' ) ) )
                    {
                    otherlv_8=(Token)match(input,36,FOLLOW_22); 

                    				newLeafNode(otherlv_8, grammarAccess.getLocalServiceAccess().getTypeKeyword_6_0());
                    			
                    // InternalTripDsl.g:1088:4: ( ( (lv_type_9_1= 'Restaurant' | lv_type_9_2= 'Hotel' ) ) )
                    // InternalTripDsl.g:1089:5: ( (lv_type_9_1= 'Restaurant' | lv_type_9_2= 'Hotel' ) )
                    {
                    // InternalTripDsl.g:1089:5: ( (lv_type_9_1= 'Restaurant' | lv_type_9_2= 'Hotel' ) )
                    // InternalTripDsl.g:1090:6: (lv_type_9_1= 'Restaurant' | lv_type_9_2= 'Hotel' )
                    {
                    // InternalTripDsl.g:1090:6: (lv_type_9_1= 'Restaurant' | lv_type_9_2= 'Hotel' )
                    int alt20=2;
                    int LA20_0 = input.LA(1);

                    if ( (LA20_0==50) ) {
                        alt20=1;
                    }
                    else if ( (LA20_0==51) ) {
                        alt20=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 20, 0, input);

                        throw nvae;
                    }
                    switch (alt20) {
                        case 1 :
                            // InternalTripDsl.g:1091:7: lv_type_9_1= 'Restaurant'
                            {
                            lv_type_9_1=(Token)match(input,50,FOLLOW_10); 

                            							newLeafNode(lv_type_9_1, grammarAccess.getLocalServiceAccess().getTypeRestaurantKeyword_6_1_0_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getLocalServiceRule());
                            							}
                            							setWithLastConsumed(current, "type", lv_type_9_1, null);
                            						

                            }
                            break;
                        case 2 :
                            // InternalTripDsl.g:1102:7: lv_type_9_2= 'Hotel'
                            {
                            lv_type_9_2=(Token)match(input,51,FOLLOW_10); 

                            							newLeafNode(lv_type_9_2, grammarAccess.getLocalServiceAccess().getTypeHotelKeyword_6_1_0_1());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getLocalServiceRule());
                            							}
                            							setWithLastConsumed(current, "type", lv_type_9_2, null);
                            						

                            }
                            break;

                    }


                    }


                    }


                    }
                    break;

            }

            otherlv_10=(Token)match(input,26,FOLLOW_2); 

            			newLeafNode(otherlv_10, grammarAccess.getLocalServiceAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLocalService"


    // $ANTLR start "entryRuleEDouble"
    // InternalTripDsl.g:1124:1: entryRuleEDouble returns [String current=null] : iv_ruleEDouble= ruleEDouble EOF ;
    public final String entryRuleEDouble() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEDouble = null;


        try {
            // InternalTripDsl.g:1124:47: (iv_ruleEDouble= ruleEDouble EOF )
            // InternalTripDsl.g:1125:2: iv_ruleEDouble= ruleEDouble EOF
            {
             newCompositeNode(grammarAccess.getEDoubleRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEDouble=ruleEDouble();

            state._fsp--;

             current =iv_ruleEDouble.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEDouble"


    // $ANTLR start "ruleEDouble"
    // InternalTripDsl.g:1131:1: ruleEDouble returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? ) ;
    public final AntlrDatatypeRuleToken ruleEDouble() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;
        Token this_INT_3=null;
        Token this_INT_7=null;


        	enterRule();

        try {
            // InternalTripDsl.g:1137:2: ( ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? ) )
            // InternalTripDsl.g:1138:2: ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? )
            {
            // InternalTripDsl.g:1138:2: ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? )
            // InternalTripDsl.g:1139:3: (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )?
            {
            // InternalTripDsl.g:1139:3: (kw= '-' )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==52) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalTripDsl.g:1140:4: kw= '-'
                    {
                    kw=(Token)match(input,52,FOLLOW_23); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEDoubleAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            // InternalTripDsl.g:1146:3: (this_INT_1= RULE_INT )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==RULE_INT) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalTripDsl.g:1147:4: this_INT_1= RULE_INT
                    {
                    this_INT_1=(Token)match(input,RULE_INT,FOLLOW_24); 

                    				current.merge(this_INT_1);
                    			

                    				newLeafNode(this_INT_1, grammarAccess.getEDoubleAccess().getINTTerminalRuleCall_1());
                    			

                    }
                    break;

            }

            kw=(Token)match(input,53,FOLLOW_25); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getEDoubleAccess().getFullStopKeyword_2());
            		
            this_INT_3=(Token)match(input,RULE_INT,FOLLOW_26); 

            			current.merge(this_INT_3);
            		

            			newLeafNode(this_INT_3, grammarAccess.getEDoubleAccess().getINTTerminalRuleCall_3());
            		
            // InternalTripDsl.g:1167:3: ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )?
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( ((LA26_0>=54 && LA26_0<=55)) ) {
                alt26=1;
            }
            switch (alt26) {
                case 1 :
                    // InternalTripDsl.g:1168:4: (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT
                    {
                    // InternalTripDsl.g:1168:4: (kw= 'E' | kw= 'e' )
                    int alt24=2;
                    int LA24_0 = input.LA(1);

                    if ( (LA24_0==54) ) {
                        alt24=1;
                    }
                    else if ( (LA24_0==55) ) {
                        alt24=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 24, 0, input);

                        throw nvae;
                    }
                    switch (alt24) {
                        case 1 :
                            // InternalTripDsl.g:1169:5: kw= 'E'
                            {
                            kw=(Token)match(input,54,FOLLOW_27); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEDoubleAccess().getEKeyword_4_0_0());
                            				

                            }
                            break;
                        case 2 :
                            // InternalTripDsl.g:1175:5: kw= 'e'
                            {
                            kw=(Token)match(input,55,FOLLOW_27); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEDoubleAccess().getEKeyword_4_0_1());
                            				

                            }
                            break;

                    }

                    // InternalTripDsl.g:1181:4: (kw= '-' )?
                    int alt25=2;
                    int LA25_0 = input.LA(1);

                    if ( (LA25_0==52) ) {
                        alt25=1;
                    }
                    switch (alt25) {
                        case 1 :
                            // InternalTripDsl.g:1182:5: kw= '-'
                            {
                            kw=(Token)match(input,52,FOLLOW_25); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEDoubleAccess().getHyphenMinusKeyword_4_1());
                            				

                            }
                            break;

                    }

                    this_INT_7=(Token)match(input,RULE_INT,FOLLOW_2); 

                    				current.merge(this_INT_7);
                    			

                    				newLeafNode(this_INT_7, grammarAccess.getEDoubleAccess().getINTTerminalRuleCall_4_2());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEDouble"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000005802000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x00000000007FC000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000005800000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000005000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000080008000000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000006000000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x00000007F0000000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000061804000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0030000000000010L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000061004000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x000001E280000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000060004000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000040004000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0001F00000000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0002001804000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0002001004000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000001004000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x000C000000000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0020000000000010L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x00C0000000000002L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0010000000000010L});

}