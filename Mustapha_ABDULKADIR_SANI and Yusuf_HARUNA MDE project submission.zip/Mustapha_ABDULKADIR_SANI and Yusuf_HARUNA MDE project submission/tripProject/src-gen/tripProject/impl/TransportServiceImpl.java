/**
 */
package tripProject.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import tripProject.TransportService;
import tripProject.TripProjectPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Transport Service</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link tripProject.impl.TransportServiceImpl#getName <em>Name</em>}</li>
 *   <li>{@link tripProject.impl.TransportServiceImpl#getCost <em>Cost</em>}</li>
 *   <li>{@link tripProject.impl.TransportServiceImpl#getType <em>Type</em>}</li>
 *   <li>{@link tripProject.impl.TransportServiceImpl#getSrce <em>Srce</em>}</li>
 *   <li>{@link tripProject.impl.TransportServiceImpl#getDest <em>Dest</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TransportServiceImpl extends ServiceImpl implements TransportService {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getCost() <em>Cost</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCost()
	 * @generated
	 * @ordered
	 */
	protected static final double COST_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getCost() <em>Cost</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCost()
	 * @generated
	 * @ordered
	 */
	protected double cost = COST_EDEFAULT;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getSrce() <em>Srce</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSrce()
	 * @generated
	 * @ordered
	 */
	protected static final String SRCE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSrce() <em>Srce</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSrce()
	 * @generated
	 * @ordered
	 */
	protected String srce = SRCE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDest() <em>Dest</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDest()
	 * @generated
	 * @ordered
	 */
	protected static final String DEST_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDest() <em>Dest</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDest()
	 * @generated
	 * @ordered
	 */
	protected String dest = DEST_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TransportServiceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return TripProjectPackage.Literals.TRANSPORT_SERVICE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, TripProjectPackage.TRANSPORT_SERVICE__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getCost() {
		return cost;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCost(double newCost) {
		double oldCost = cost;
		cost = newCost;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, TripProjectPackage.TRANSPORT_SERVICE__COST, oldCost,
					cost));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, TripProjectPackage.TRANSPORT_SERVICE__TYPE, oldType,
					type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSrce() {
		return srce;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSrce(String newSrce) {
		String oldSrce = srce;
		srce = newSrce;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, TripProjectPackage.TRANSPORT_SERVICE__SRCE, oldSrce,
					srce));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDest() {
		return dest;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDest(String newDest) {
		String oldDest = dest;
		dest = newDest;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, TripProjectPackage.TRANSPORT_SERVICE__DEST, oldDest,
					dest));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case TripProjectPackage.TRANSPORT_SERVICE__NAME:
			return getName();
		case TripProjectPackage.TRANSPORT_SERVICE__COST:
			return getCost();
		case TripProjectPackage.TRANSPORT_SERVICE__TYPE:
			return getType();
		case TripProjectPackage.TRANSPORT_SERVICE__SRCE:
			return getSrce();
		case TripProjectPackage.TRANSPORT_SERVICE__DEST:
			return getDest();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case TripProjectPackage.TRANSPORT_SERVICE__NAME:
			setName((String) newValue);
			return;
		case TripProjectPackage.TRANSPORT_SERVICE__COST:
			setCost((Double) newValue);
			return;
		case TripProjectPackage.TRANSPORT_SERVICE__TYPE:
			setType((String) newValue);
			return;
		case TripProjectPackage.TRANSPORT_SERVICE__SRCE:
			setSrce((String) newValue);
			return;
		case TripProjectPackage.TRANSPORT_SERVICE__DEST:
			setDest((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case TripProjectPackage.TRANSPORT_SERVICE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case TripProjectPackage.TRANSPORT_SERVICE__COST:
			setCost(COST_EDEFAULT);
			return;
		case TripProjectPackage.TRANSPORT_SERVICE__TYPE:
			setType(TYPE_EDEFAULT);
			return;
		case TripProjectPackage.TRANSPORT_SERVICE__SRCE:
			setSrce(SRCE_EDEFAULT);
			return;
		case TripProjectPackage.TRANSPORT_SERVICE__DEST:
			setDest(DEST_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case TripProjectPackage.TRANSPORT_SERVICE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case TripProjectPackage.TRANSPORT_SERVICE__COST:
			return cost != COST_EDEFAULT;
		case TripProjectPackage.TRANSPORT_SERVICE__TYPE:
			return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
		case TripProjectPackage.TRANSPORT_SERVICE__SRCE:
			return SRCE_EDEFAULT == null ? srce != null : !SRCE_EDEFAULT.equals(srce);
		case TripProjectPackage.TRANSPORT_SERVICE__DEST:
			return DEST_EDEFAULT == null ? dest != null : !DEST_EDEFAULT.equals(dest);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", cost: ");
		result.append(cost);
		result.append(", type: ");
		result.append(type);
		result.append(", srce: ");
		result.append(srce);
		result.append(", dest: ");
		result.append(dest);
		result.append(')');
		return result.toString();
	}

} //TransportServiceImpl
