/**
 */
package tripProject;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see tripProject.TripProjectFactory
 * @model kind="package"
 * @generated
 */
public interface TripProjectPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "tripProject";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/tripProject";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "tripProject";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	TripProjectPackage eINSTANCE = tripProject.impl.TripProjectPackageImpl.init();

	/**
	 * The meta object id for the '{@link tripProject.impl.TripImpl <em>Trip</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see tripProject.impl.TripImpl
	 * @see tripProject.impl.TripProjectPackageImpl#getTrip()
	 * @generated
	 */
	int TRIP = 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP__SOURCE = 0;

	/**
	 * The feature id for the '<em><b>Destination</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP__DESTINATION = 1;

	/**
	 * The feature id for the '<em><b>Service</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP__SERVICE = 2;

	/**
	 * The number of structural features of the '<em>Trip</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Trip</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link tripProject.impl.ServiceImpl <em>Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see tripProject.impl.ServiceImpl
	 * @see tripProject.impl.TripProjectPackageImpl#getService()
	 * @generated
	 */
	int SERVICE = 1;

	/**
	 * The number of structural features of the '<em>Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link tripProject.impl.TransportServiceImpl <em>Transport Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see tripProject.impl.TransportServiceImpl
	 * @see tripProject.impl.TripProjectPackageImpl#getTransportService()
	 * @generated
	 */
	int TRANSPORT_SERVICE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORT_SERVICE__NAME = SERVICE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Cost</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORT_SERVICE__COST = SERVICE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORT_SERVICE__TYPE = SERVICE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Srce</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORT_SERVICE__SRCE = SERVICE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Dest</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORT_SERVICE__DEST = SERVICE_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Transport Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORT_SERVICE_FEATURE_COUNT = SERVICE_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Transport Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORT_SERVICE_OPERATION_COUNT = SERVICE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link tripProject.impl.LocalServiceImpl <em>Local Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see tripProject.impl.LocalServiceImpl
	 * @see tripProject.impl.TripProjectPackageImpl#getLocalService()
	 * @generated
	 */
	int LOCAL_SERVICE = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCAL_SERVICE__NAME = SERVICE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Cost</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCAL_SERVICE__COST = SERVICE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCAL_SERVICE__LOCATION = SERVICE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCAL_SERVICE__TYPE = SERVICE_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Local Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCAL_SERVICE_FEATURE_COUNT = SERVICE_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Local Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOCAL_SERVICE_OPERATION_COUNT = SERVICE_OPERATION_COUNT + 0;

	/**
	 * Returns the meta object for class '{@link tripProject.Trip <em>Trip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Trip</em>'.
	 * @see tripProject.Trip
	 * @generated
	 */
	EClass getTrip();

	/**
	 * Returns the meta object for the attribute '{@link tripProject.Trip#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Source</em>'.
	 * @see tripProject.Trip#getSource()
	 * @see #getTrip()
	 * @generated
	 */
	EAttribute getTrip_Source();

	/**
	 * Returns the meta object for the attribute '{@link tripProject.Trip#getDestination <em>Destination</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Destination</em>'.
	 * @see tripProject.Trip#getDestination()
	 * @see #getTrip()
	 * @generated
	 */
	EAttribute getTrip_Destination();

	/**
	 * Returns the meta object for the containment reference list '{@link tripProject.Trip#getService <em>Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Service</em>'.
	 * @see tripProject.Trip#getService()
	 * @see #getTrip()
	 * @generated
	 */
	EReference getTrip_Service();

	/**
	 * Returns the meta object for class '{@link tripProject.Service <em>Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Service</em>'.
	 * @see tripProject.Service
	 * @generated
	 */
	EClass getService();

	/**
	 * Returns the meta object for class '{@link tripProject.TransportService <em>Transport Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transport Service</em>'.
	 * @see tripProject.TransportService
	 * @generated
	 */
	EClass getTransportService();

	/**
	 * Returns the meta object for the attribute '{@link tripProject.TransportService#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see tripProject.TransportService#getName()
	 * @see #getTransportService()
	 * @generated
	 */
	EAttribute getTransportService_Name();

	/**
	 * Returns the meta object for the attribute '{@link tripProject.TransportService#getCost <em>Cost</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cost</em>'.
	 * @see tripProject.TransportService#getCost()
	 * @see #getTransportService()
	 * @generated
	 */
	EAttribute getTransportService_Cost();

	/**
	 * Returns the meta object for the attribute '{@link tripProject.TransportService#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see tripProject.TransportService#getType()
	 * @see #getTransportService()
	 * @generated
	 */
	EAttribute getTransportService_Type();

	/**
	 * Returns the meta object for the attribute '{@link tripProject.TransportService#getSrce <em>Srce</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Srce</em>'.
	 * @see tripProject.TransportService#getSrce()
	 * @see #getTransportService()
	 * @generated
	 */
	EAttribute getTransportService_Srce();

	/**
	 * Returns the meta object for the attribute '{@link tripProject.TransportService#getDest <em>Dest</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dest</em>'.
	 * @see tripProject.TransportService#getDest()
	 * @see #getTransportService()
	 * @generated
	 */
	EAttribute getTransportService_Dest();

	/**
	 * Returns the meta object for class '{@link tripProject.LocalService <em>Local Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Local Service</em>'.
	 * @see tripProject.LocalService
	 * @generated
	 */
	EClass getLocalService();

	/**
	 * Returns the meta object for the attribute '{@link tripProject.LocalService#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see tripProject.LocalService#getName()
	 * @see #getLocalService()
	 * @generated
	 */
	EAttribute getLocalService_Name();

	/**
	 * Returns the meta object for the attribute '{@link tripProject.LocalService#getCost <em>Cost</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cost</em>'.
	 * @see tripProject.LocalService#getCost()
	 * @see #getLocalService()
	 * @generated
	 */
	EAttribute getLocalService_Cost();

	/**
	 * Returns the meta object for the attribute '{@link tripProject.LocalService#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Location</em>'.
	 * @see tripProject.LocalService#getLocation()
	 * @see #getLocalService()
	 * @generated
	 */
	EAttribute getLocalService_Location();

	/**
	 * Returns the meta object for the attribute '{@link tripProject.LocalService#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see tripProject.LocalService#getType()
	 * @see #getLocalService()
	 * @generated
	 */
	EAttribute getLocalService_Type();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	TripProjectFactory getTripProjectFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link tripProject.impl.TripImpl <em>Trip</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see tripProject.impl.TripImpl
		 * @see tripProject.impl.TripProjectPackageImpl#getTrip()
		 * @generated
		 */
		EClass TRIP = eINSTANCE.getTrip();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP__SOURCE = eINSTANCE.getTrip_Source();

		/**
		 * The meta object literal for the '<em><b>Destination</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP__DESTINATION = eINSTANCE.getTrip_Destination();

		/**
		 * The meta object literal for the '<em><b>Service</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIP__SERVICE = eINSTANCE.getTrip_Service();

		/**
		 * The meta object literal for the '{@link tripProject.impl.ServiceImpl <em>Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see tripProject.impl.ServiceImpl
		 * @see tripProject.impl.TripProjectPackageImpl#getService()
		 * @generated
		 */
		EClass SERVICE = eINSTANCE.getService();

		/**
		 * The meta object literal for the '{@link tripProject.impl.TransportServiceImpl <em>Transport Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see tripProject.impl.TransportServiceImpl
		 * @see tripProject.impl.TripProjectPackageImpl#getTransportService()
		 * @generated
		 */
		EClass TRANSPORT_SERVICE = eINSTANCE.getTransportService();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSPORT_SERVICE__NAME = eINSTANCE.getTransportService_Name();

		/**
		 * The meta object literal for the '<em><b>Cost</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSPORT_SERVICE__COST = eINSTANCE.getTransportService_Cost();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSPORT_SERVICE__TYPE = eINSTANCE.getTransportService_Type();

		/**
		 * The meta object literal for the '<em><b>Srce</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSPORT_SERVICE__SRCE = eINSTANCE.getTransportService_Srce();

		/**
		 * The meta object literal for the '<em><b>Dest</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSPORT_SERVICE__DEST = eINSTANCE.getTransportService_Dest();

		/**
		 * The meta object literal for the '{@link tripProject.impl.LocalServiceImpl <em>Local Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see tripProject.impl.LocalServiceImpl
		 * @see tripProject.impl.TripProjectPackageImpl#getLocalService()
		 * @generated
		 */
		EClass LOCAL_SERVICE = eINSTANCE.getLocalService();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCAL_SERVICE__NAME = eINSTANCE.getLocalService_Name();

		/**
		 * The meta object literal for the '<em><b>Cost</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCAL_SERVICE__COST = eINSTANCE.getLocalService_Cost();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCAL_SERVICE__LOCATION = eINSTANCE.getLocalService_Location();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOCAL_SERVICE__TYPE = eINSTANCE.getLocalService_Type();

	}

} //TripProjectPackage
