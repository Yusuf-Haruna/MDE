/**
 */
package tripProject;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Service</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see tripProject.TripProjectPackage#getService()
 * @model abstract="true"
 * @generated
 */
public interface Service extends EObject {
} // Service
